/**

La clase Nodo representa un nodo de un �rbol binario de b�squeda. Cada nodo tiene una asociaci�n de ClaveValor, y apunta a dos hijos: el hijo izquierdo y el hijo derecho.
Y guarda un elemento ClaveValor
*/
package es.upm.dit.adsw.p2;

public class Nodo {
	private CV cv;
	private Nodo hijoIzquierdo;
	private Nodo hijoDerecho;

	/**
	 * Constructor de la clase Nodo.
	 *
	 * @param cv la asociaci�n de ClaveValor que se desea guardar en este nodo
	 */
	public Nodo(CV cv) {
		this.cv = cv;
	}

	/**
	 * Retorna el hijo izquierdo de este nodo.
	 *
	 * @return el nodo hijo izquierdo
	 */
	public Nodo getHijoIzquierdo() {
		return hijoIzquierdo;
	}

	/**
	 * Establece el hijo izquierdo de este nodo.
	 *
	 * @param hijoIzquierdo el nuevo nodo hijo izquierdo que se desea asociar con
	 *                      este nodo
	 */
	public void setHijoIzquierdo(Nodo hijoIzquierdo) {
		this.hijoIzquierdo = hijoIzquierdo;
	}

	/**
	 * Retorna el hijo derecho de este nodo.
	 *
	 * @return el nodo hijo derecho
	 */
	public Nodo getHijoDerecho() {
		return hijoDerecho;
	}

	/**
	 * Establece el hijo derecho de este nodo.
	 *
	 * @param hijoDerecho el nuevo nodo hijo derecho que se desea asociar con este
	 *                    nodo
	 */
	public void setHijoDerecho(Nodo hijoDerecho) {
		this.hijoDerecho = hijoDerecho;
	}

	/**
	 * Retorna la asociaci�n de ClaveValor guardada en este nodo.
	 *
	 * @return la asociaci�n de ClaveValor guardada en este nodo
	 */
	public CV getCv() {
		return cv;
	}

	/**
	 * Establece la asociaci�n de ClaveValor que se quiere guardar en este nodo.
	 *
	 * @param cv la nueva asociaci�n de ClaveValor que se quiere guardar en este
	 *           nodo
	 */
	public void setCv(CV cv) {
		this.cv = cv;
	}
}