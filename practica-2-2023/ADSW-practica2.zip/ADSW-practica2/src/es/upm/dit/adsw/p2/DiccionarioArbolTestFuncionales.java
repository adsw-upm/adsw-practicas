/**

Clase de pruebas para la clase Arbol.
*/
package es.upm.dit.adsw.p2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import es.upm.dit.adsw.geosocial.*;

class DiccionarioArbolTestFuncionales {

	private DiccionarioArbol arbol;

	/**
	 * 
	 * Inicializa el árbol para los tests.
	 */
	@BeforeEach
	void setUp() {
		arbol = new DiccionarioArbol();
	}

	/**
	 * 
	 * Este test solo sirve para saber si tienes el método getRaiz
	 */
	@Test
	public void testGetRaiz() {
		assertEquals(null, arbol.getRaiz());
	}

	/**
	 * 
	 * Este test solo sirve para saber si tienes el método setRaiz
	 */
	@Test
	public void testSetRaiz() {
		Usuario usu1 = new Usuario(1);
		arbol.setRaiz(new Nodo(new CV(usu1.getId(), usu1)));
		assertNotNull(arbol.getRaiz());
	}

	/**
	 * 
	 * Prueba los métodos put() y get() de la clase Arbol.
	 */
	@Test
	void testPutAndGet() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		assertEquals(usu1, arbol.get(1));
		assertEquals(usu2, arbol.get(2));
		assertEquals(usu3, arbol.get(3));
	}

	/**
	 * 
	 * Prueba el método remove() de la clase Arbol.
	 */
	@Test
	void testRemove() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		assertEquals(usu1, (arbol.remove(2)).getCv().getUsuario());
		assertNull(arbol.get(2));
		assertEquals(2, arbol.size());
		assertEquals(usu1, (arbol.remove(3)).getCv().getUsuario());
		assertNull(arbol.get(3));
		assertEquals(1, arbol.size());
		assertNull((arbol.remove(1)));
	}

	/**
	 * 
	 * Prueba el método size() de la clase Arbol.
	 */
	@Test
	void testSize() {
		assertEquals(0, arbol.size());
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		assertEquals(3, arbol.size());
	}

	/**
	 * 
	 * Prueba el método clear() de la clase Arbol.
	 */
	@Test
	void testClear() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		arbol.clear();
		assertEquals(0, arbol.size());
		assertNull(arbol.get(1));
		assertNull(arbol.get(2));
		assertNull(arbol.get(3));
	}

	/**
	 * 
	 * Prueba los métodos put() y get() de la clase Arbol y el comportamiento de
	 * put() cuando se actualiza un valor.
	 */
	@Test
	void testPutAndGetUpdateValue() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu11 = new Usuario(11);
		Usuario usu22 = new Usuario(22);
		Usuario usu33 = new Usuario(33);
		arbol.put(1, usu1);
		arbol.put(2, usu2);
		arbol.put(3, usu3);
		arbol.put(1, usu11);
		arbol.put(2, usu22);
		arbol.put(3, usu33);
		assertEquals(usu11, arbol.get(1));
		assertEquals(usu22, arbol.get(2));
		assertEquals(usu33, arbol.get(3));
	}

	/**
	 * 
	 * Prueba el método getHeight() de la clase Arbol.
	 */
	@Test
	public void testGetHeight() {
		DiccionarioArbol arbol = new DiccionarioArbol();
		assertEquals(0, arbol.getHeight());
		Usuario usu0 = new Usuario(0);
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu4 = new Usuario(4);
		Usuario usu5 = new Usuario(5);
		Usuario usu6 = new Usuario(6);

		arbol.put(usu3.getId(), usu3);
		assertEquals(1, arbol.getHeight());

		arbol.put(usu1.getId(), usu1);
		arbol.put(usu5.getId(), usu5);
		assertEquals(2, arbol.getHeight());

		arbol.put(usu4.getId(), usu4);
		arbol.put(usu6.getId(), usu6);
		assertEquals(3, arbol.getHeight());

		arbol.put(usu2.getId(), usu2);
		assertEquals(3, arbol.getHeight());

		arbol.put(usu0.getId(), usu0);
		assertEquals(3, arbol.getHeight());

		arbol.clear();
		assertEquals(0, arbol.getHeight());
	}

	/**
	 * 
	 * Prueba el método inOrder() de la clase Arbol con un árbol vacío.
	 */
	@Test
	public void testInOrderEmpty() {
		List<Integer> expected = new ArrayList<Integer>();
		List<Integer> result = arbol.inOrder();
		assertEquals(expected, result);
	}

	/**
	 * 
	 * Prueba el método inOrder() de la clase Arbol con un árbol no vacío.
	 */
	@Test
	public void testInOrder() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu4 = new Usuario(4);
		Usuario usu5 = new Usuario(5);
		Usuario usu6 = new Usuario(6);
		Usuario usu7 = new Usuario(7);

		arbol.put(usu4.getId(), usu4);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu6.getId(), usu6);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu3.getId(), usu3);
		arbol.put(usu5.getId(), usu5);
		arbol.put(usu7.getId(), usu7);

		List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
		List<Integer> result = arbol.inOrder();
		assertEquals(expected, result);
	}

	/**
	 * 
	 * Prueba unitaria que verifica si el método preOrder() devuelve una lista vacía
	 * cuando el árbol está vacío.
	 */
	@Test
	public void testPreOrderEmpty() {
		List<Integer> expected = new ArrayList<Integer>();
		List<Integer> result = arbol.preOrder();
		assertEquals(expected, result);
	}

	/**
	 * 
	 * Prueba unitaria que verifica si el método preOrder() devuelve la lista
	 * esperada de nodos en preorden.
	 * 
	 * Se agregan varios nodos al árbol y se verifica si el recorrido en preorden es
	 * correcto.
	 */
	@Test
	public void testPreOrder() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu4 = new Usuario(4);
		Usuario usu5 = new Usuario(5);
		Usuario usu6 = new Usuario(6);
		Usuario usu7 = new Usuario(7);

		arbol.put(usu4.getId(), usu4);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu6.getId(), usu6);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu3.getId(), usu3);
		arbol.put(usu5.getId(), usu5);
		arbol.put(usu7.getId(), usu7);

		List<Integer> expected = Arrays.asList(4, 2, 1, 3, 6, 5, 7);
		List<Integer> result = arbol.preOrder();
		assertEquals(expected, result);
	}

	/**
	 * 
	 * Prueba unitaria que verifica si el método postOrder() devuelve una lista
	 * vacía cuando el árbol está vacío.
	 */
	@Test
	public void testPostOrderEmpty() {
		List<Integer> expected = new ArrayList<Integer>();
		List<Integer> result = arbol.postOrder();
		assertEquals(expected, result);
	}

	/**
	 * 
	 * Prueba unitaria que verifica si el método postOrder() devuelve la lista
	 * esperada de nodos en postorden. Se agregan varios nodos al árbol y se
	 * verifica si el recorrido en postorden es correcto.
	 * 
	 */
	@Test
	public void testPostOrder() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu4 = new Usuario(4);
		Usuario usu5 = new Usuario(5);
		Usuario usu6 = new Usuario(6);
		Usuario usu7 = new Usuario(7);

		arbol.put(usu4.getId(), usu4);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu6.getId(), usu6);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu3.getId(), usu3);
		arbol.put(usu5.getId(), usu5);
		arbol.put(usu7.getId(), usu7);

		List<Integer> expected = Arrays.asList(1, 3, 2, 5, 7, 6, 4);
		List<Integer> result = arbol.postOrder();
		assertEquals(expected, result);
	}

	/**
	 * 
	 * Prueba unitaria que verifica si dos árboles son iguales, nodo a nodo.
	 * 
	 */
	@Test
	public void testEquals() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu4 = new Usuario(4);
		Usuario usu5 = new Usuario(5);
		Usuario usu6 = new Usuario(6);
		Usuario usu7 = new Usuario(7);

		arbol.put(usu4.getId(), usu4);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu6.getId(), usu6);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu3.getId(), usu3);
		arbol.put(usu5.getId(), usu5);
		arbol.put(usu7.getId(), usu7);

		DiccionarioArbol otroArbol = new DiccionarioArbol();
		assertFalse(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");

		otroArbol.put(usu4.getId(), usu4);
		assertFalse(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");

		otroArbol.put(usu2.getId(), usu2);
		assertFalse(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");

		otroArbol.put(usu6.getId(), usu6);
		assertFalse(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");

		otroArbol.put(usu1.getId(), usu1);
		assertFalse(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");

		otroArbol.put(usu3.getId(), usu3);
		assertFalse(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");

		otroArbol.put(usu5.getId(), usu5);
		assertFalse(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");

		otroArbol.put(usu7.getId(), usu7);
		assertTrue(this.arbol.equals(otroArbol), "El método equals de DiccionarioArbol falla.");
	}

}