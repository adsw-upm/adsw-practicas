package es.upm.dit.adsw.p2;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.*;
import es.upm.dit.adsw.geosocial.*;

public class PruebaInsercionBusqueda {

// static method returns list of random integers 
// size of list is passed as parameter
	public static List<Integer> getRandomList(int size) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < size; i++) {
			list.add(i);
		}
		Collections.shuffle(list);
		return list;
	}

// static method returning a Diccionario filled with list of random integers
// size of list is passed as parameter the Diccionario to be filled is passed as parameter
// return the Diccionario filled
	public static Diccionario getDiccionario(int size, Diccionario dic) {
		List<Integer> listaShuffle = getRandomList(size);
		for (Integer id : listaShuffle) {
			Usuario usu = new Usuario(id);
			dic.put(usu.getId(), usu);
		}
		return dic;
	}

	public static void pruebaInsercionDatos(int size, Diccionario dic) {
		// Crear una nueva fecha para luego calcular el tiempo de ejecución
		Date dateBefore = new Date();
		// Mostrar la hora actual
		System.out.println("Hora inicio: " + dateBefore.toString());
		// fill the Diccionario with random integers
		dic = getDiccionario(size, dic);
		// Crear una nueva fecha para luego calcular el tiempo de ejecución
		Date dateAfter = new Date();
		// Mostrar la fecha y hora actual
		System.out.println("Hora finalización: " + dateAfter.toString());
		// Mostrar el tiempo de ejecución en segundos y milisegundos
		System.out.println("Tiempo de ejecución la inserción de datos: "
				+ (double) (dateAfter.getTime() - dateBefore.getTime()) / 1000.0 + " segundos");
	}

	// Método static para probar la búsqueda de datos en el Diccionario
	// se hará una bateria de búsquedas indicadas por parámetro
	// se mostrará el tiempo de ejecución de todas las búsquedas
	public static void pruebaBusquedaDatos(int size, Diccionario dic) {
		// Crear una nueva fecha para luego calcular el tiempo de ejecución
		Date dateBefore = new Date();
		// Mostrar la hora actual
		System.out.println("Hora inicio: " + dateBefore.toString());
		// hacer un for para buscar números aleatorios en el diccionario
		for (int i = 0; i < size; i++) {
			// Generar un número aleatorio
			int id = (int) (Math.random() * size);
			// Buscar el número en el diccionario
			dic.get(id);
		}
		// Crear una nueva fecha para luego calcular el tiempo de ejecución
		Date dateAfter = new Date();
		// Mostrar la fecha y hora actual
		System.out.println("Hora finalización: " + dateAfter.toString());
		// Mostrar el tiempo de ejecución en segundos y milisegundos
		System.out.println("Tiempo de ejecución de la búsqueda de datos: "
				+ (double) (dateAfter.getTime() - dateBefore.getTime()) / 1000.0 + " segundos");
	}

	public static void probarInsercionesBusquedas(int size, Diccionario dic) {
		// Prueba de inserción de datos DiccionarioArrayDesordenado
		System.out.println("----------------------------------------------------------------------------------------");
		System.out.println("Prueba de inserción de datos con DiccionarioArrayDesordenado y tamaño: " + size);
		System.out.println("----------------------------------------------------------------------------------------");
		pruebaInsercionDatos(size, dic);

		// Ejecución de la prueba de búsqueda de datos para el diccionario de tipo
		// DiccionarioArrayDesordenado
		System.out.println("----------------------------------------------------------------------------------------");
		System.out.println("Prueba de búsqueda de datos con DiccionarioArrayDesordenado y tamaño: " + size);
		System.out.println("----------------------------------------------------------------------------------------");
		pruebaBusquedaDatos(size, dic);
	}

	public static void main(String[] args) throws FileNotFoundException, ParseException {
		// TODO Auto-generated method stub
		// Inicialización de variables
		int size = 100000;
		// Creamos un diccionario de tipo DiccionarioArrayOrdenado
		DiccionarioArrayDesordenado dic = new DiccionarioArrayDesordenado(size);
		probarInsercionesBusquedas(size, dic);

		// Creamos un diccionario de tipo DiccionarioArbol
		DiccionarioArbol dicArbol = new DiccionarioArbol();
		probarInsercionesBusquedas(size, dicArbol);
		System.out.println("Altura: " + dicArbol.getHeight());

	}

}
