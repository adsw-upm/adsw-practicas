/**

Clase que representa un árbol binario de búsqueda que implementa la interfaz Diccionario.
Esta clase permite insertar, buscar, eliminar y conocer el número de elementos del árbol.
El árbol está formado por nodos de la clase Nodo, que contienen cada uno un objeto de la clase CV.
Los nodos están organizados de forma que cada nodo tiene dos hijos, uno izquierdo y otro derecho, y los nodos
del subárbol izquierdo tienen claves menores que la del nodo padre, mientras que los nodos del subárbol derecho
tienen claves mayores.
*/
package es.upm.dit.adsw.p2;

import java.util.ArrayList;
import java.util.List;

import es.upm.dit.adsw.geosocial.*;

public class DiccionarioArbol implements Diccionario {
	private Nodo raiz;

	/**
	 * Constructor de la clase Arbol que inicializa la raíz a null.
	 */
	public DiccionarioArbol() {
		raiz = null;
	}

	/**
	 * Devuelve el nodo raíz del árbol.
	 *
	 * @return el nodo raíz del árbol.
	 */
	public Nodo getRaiz() {
		return raiz;
	}

	/**
	 * Establece el nodo raíz del árbol.
	 *
	 * @param raiz el nuevo nodo raíz del árbol.
	 */
	public void setRaiz(Nodo raiz) {
		this.raiz = raiz;
	}

	/**
	 * Método recursivo para insertar un objeto CV en el árbol usando búsqueda
	 * binaria y recursión. Si la clave ya existe, se actualiza el valor.
	 * 
	 * @param nodo El nodo en el que se desea insertar el objeto CV.
	 * @param cv   El objeto CV que se desea insertar.
	 */
	private void put(Nodo nodo, CV cv) {
		//TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
	}

	/**
	 * Método para insertar un nuevo objeto CV en la raíz del árbol. Si queremos
	 * hacerlo de forma recursiva debe llamar a "void put(Nodo nodo, CV cv)" con la
	 * raíz del árbol si no es null Y si es null crear un nuevo nodo.
	 * 
	 * @param clave La clave del objeto CV que se desea insertar.
	 * @param usu   El usuario del objeto CV que se desea insertar.
	 */
	@Override
	public void put(Integer clave, Usuario usu) {
		//TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
	}

	/**
	 * Método para obtener el valor de una clave usando búsqueda binaria y
	 * recursión.
	 * 
	 * @param nodo  El nodo a partir del cual se comienza a buscar el valor.
	 * @param clave La clave del valor que se desea buscar.
	 * @return El usuario correspondiente a la clave buscada, o null si la clave no
	 *         se encuentra en el árbol.
	 */
	private Usuario get(Nodo nodo, int clave) {
		// TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
		return null;
	}

	/**
	 * 
	 * Devuelve el usuario asociado a la clave especificada en el árbol. Si queremos
	 * hacerlo de forma recursiva debe llamar "Usuario get(Nodo nodo, int clave)"
	 * con la raíz del árbol.
	 * 
	 * @param clave La clave del usuario que se desea buscar.
	 * @return El usuario asociado a la clave especificada si se encuentra en el
	 *         árbol; de lo contrario, devuelve null.
	 */
	@Override
	public Usuario get(Integer clave) {
		// TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
		return null;
	}

	/**
	 * 
	 * Método para eliminar un objeto CV por la clave de un árbol binario de
	 * búsqueda utilizando recursividad. Si queremos hacerlo de forma recursiva debe
	 * llamar a "Nodo remove(Nodo nodo, int clave)" con la raíz del árbol.
	 * 
	 * 
	 * @param clave la clave del objeto CV a eliminar
	 * @return el nodo padre del nodo que contiene el objeto CV eliminado, o null si
	 *         la clave no fue encontrada
	 */
	@Override
	public Nodo remove(Integer clave) {
		//TODO para la práctica 2 debes hacer éste código
		return null;
	}

	/**
	 * 
	 * Método para eliminar un objeto CV por la clave de un árbol binario de
	 * búsqueda utilizando recursión. Si la clave no se encuentra, devuelve null.
	 * 
	 * @param nodo  El nodo a partir del cual se buscará el objeto a eliminar.
	 * @param clave La clave del objeto CV a eliminar.
	 * @return el nodo padre del nodo que contiene el objeto CV eliminado, o null si
	 *         la clave no fue encontrada
	 */
	private Nodo remove(Nodo nodo, int clave) {
		//TODO para la práctica 2 debes hacer éste código
		return null;
	}

	/**
	 * 
	 * Devuelve el número de objetos CV en el árbol utilizando el algoritmo de
	 * búsqueda binaria mediante recursión. Si queremos hacerlo de forma recursiva
	 * debe llamar a "int size(Nodo nodo)" con la raíz del árbol.
	 * 
	 * @return El número de objetos CV en el árbol.
	 */
	@Override
	public int size() {
		//TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
		return 0;
	}

	/**
	 * 
	 * Método que devuelve el número de objetos CV en el árbol utilizando el árbol
	 * binario de búsqueda mediante recursión.
	 * 
	 * @param nodo El nodo raíz del subárbol actual.
	 * @return El número de objetos CV en el árbol.
	 */
	private int size(Nodo nodo) {
		//TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
		return 0;
	}

	/**
	 * 
	 * Elimina todos los objetos CV del árbol binario de búsqueda mediante
	 * recursión. La raíz del árbol se establece en null.
	 */
	@Override
	public void clear() {
		// TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
	}

	/**
	 * 
	 * Método para dibujar el árbol. Se utiliza para visualizar la estructura del
	 * árbol de una manera gráfica.
	 * 
	 * @param nodo  El nodo raíz del árbol a dibujar.
	 * @param nivel El nivel de profundidad del nodo actual. Usado para posicionar
	 *              correctamente los nodos en la impresión.
	 */
	public void draw() {
		draw(raiz, 0);
	}

	/**
	 * 
	 * Método para dibujar verticalmente el árbol usando arte ASCII con líneas que
	 * conectan los nodos.
	 * 
	 * @param nodo el nodo actual a dibujar
	 */
	private void draw(Nodo nodo, int nivel) {
		if (nodo != null) {
			draw(nodo.getHijoDerecho(), nivel + 1);
			for (int i = 0; i < nivel; i++) {
				System.out.print(" ");
			}
			System.out.println(nodo.getCv().getClave());
			draw(nodo.getHijoIzquierdo(), nivel + 1);
		}
	}

	/**
	 * 
	 * Este método devuelve la altura del árbol, es decir, la longitud del camino
	 * más largo desde la raíz hasta una hoja del árbol. Si queremos hacerlo de
	 * forma recursiva debe llamar a "int getHeight(Nodo nodo)" con la raíz del
	 * árbol.
	 * 
	 * @return la altura del árbol
	 */
	public int getHeight() {
		// TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
		return 0;
	}

	/**
	 * 
	 * Devuelve la altura del árbol.
	 * 
	 * @param nodo El nodo raíz del árbol del cual se quiere obtener la altura.
	 * @return La altura del árbol. Si el nodo es nulo, retorna 0.
	 */
	private int getHeight(Nodo nodo) {
		// TODO este código ya lo tienes en el Laboratorio 2, debes copiarlo aquí
		return 0;
	}

	/**
	 * 
	 * Método inOrder para obtener la lista de objetos CV en el árbol usando un
	 * árbol de búsqueda binario desde la raíz. Si queremos hacerlo de forma
	 * recursiva debe llamar a "void inOrder(Nodo nodo, List<Integer> lista)" con la
	 * raíz del árbol.
	 * 
	 * @return una lista de enteros que representa las claves de objetos CV
	 *         recorridos "en orden"
	 */
	public List<Integer> inOrder() {
		// TODO para la práctica 2 debes hacer éste código
		return null;
	}

	/**
	 * 
	 * Método inOrder auxiliar para obtener la lista de objetos CV en el árbol
	 * usando un árbol de búsqueda binario mediante recursión.
	 * 
	 * @param nodo  el nodo actual que se está examinando
	 * @param lista la lista donde se van a almacenar las claves de los objetos CV
	 *              "en orden"
	 */
	private void inOrder(Nodo nodo, List<Integer> lista) {
		// TODO para la práctica 2 debes hacer éste código
	}

	/**
	 * 
	 * Método preOrder para obtener una lista de objetos CV en el árbol usando un
	 * árbol binario de búsqueda desde la raíz. Si queremos hacerlo de forma
	 * recursiva debe llamar a "void preOrder(Nodo nodo, List<Integer> lista)" con
	 * la raíz del árbol.
	 * 
	 * 
	 * @return Una lista de objetos Integer con las claves en pre-orden.
	 */
	public List<Integer> preOrder() {
		//TODO para la práctica 2 debes hacer éste código
				return null;
	}

	/**
	 * 
	 * Método auxiliar para preOrder que agrega las claves de los nodos a la lista
	 * dada en pre-orden mediante recursion.
	 * 
	 * @param nodo  Nodo actual del árbol a recorrer.
	 * @param lista Lista donde se almacenan las claves en pre-orden.
	 */
	private void preOrder(Nodo nodo, List<Integer> lista) {
		//TODO para la práctica 2 debes hacer éste código
	}

	/**
	 * 
	 * Método postOrder que devuelve una lista con los objetos CV del árbol en orden
	 * posterior utilizando una búsqueda binaria. Si queremos hacerlo de forma
	 * recursiva debe llamar a "void postOrder(Nodo nodo, List<Integer> lista)" con
	 * la raíz del árbol.
	 * 
	 * @return una lista de objetos Integer con las claves en orden posterior.
	 */
	public List<Integer> postOrder() {
		// TODO para la práctica 2 debes hacer éste código
		return null;
	}

	/**
	 * 
	 * Método auxiliar postOrder que recorre los nodos del árbol en orden posterior
	 * utilizando una búsqueda binaria recursiva.
	 * 
	 * @param nodo  el nodo actual a recorrer.
	 * @param lista la lista que almacenará las claves de los objetos CV en orden
	 *              posterior.
	 */
	private void postOrder(Nodo nodo, List<Integer> lista) {
		//TODO para la práctica 2 debes hacer éste código
	}

	/**
	 * 
	 * Compara si el objeto actual es igual a otro objeto pasado por parámetro. Debe
	 * hacer uso del método private boolean equals(Nodo, Nodo)
	 * 
	 * @param otroArbol es el otro árbol con el que se desea comparar el objeto
	 *                  actual
	 * @return true si los objetos son iguales, false en caso contrario. Pero deben
	 *         ser iguales nodo a nodo, es decir, no solo comprueba si los nodos
	 *         raíz son iguales.
	 */

	@Override
	public boolean equals(Object otroArbol) {
		DiccionarioArbol other = (DiccionarioArbol) otroArbol;
		return equals(this.raiz, other.raiz);
	}

	/**
	 * 
	 * Método recursivo que compara dos nodos para determinar si son iguales. No
	 * únicamente los nodos, si no también sus hijos y los hijos de los hijos, etc.
	 * 
	 * @param unNodo   el primer nodo a comparar
	 * 
	 * @param otroNodo el segundo nodo a comparar
	 * 
	 * @return true si los nodos son iguales (y los hijos e hijos de los hijos...),
	 *         false en caso contrario
	 */
	private boolean equals(Nodo unNodo, Nodo otroNodo) {
		// TODO para la práctica 2 debes hacer éste código
		return false;
	}

}