package es.upm.dit.adsw.p2;

import es.upm.dit.adsw.geosocial.Usuario;

public class PruebaPintar {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DiccionarioArbol arbol = new DiccionarioArbol();
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu4 = new Usuario(4);
		Usuario usu5 = new Usuario(5);
		Usuario usu6 = new Usuario(6);
		Usuario usu7 = new Usuario(7);
		Usuario usu8 = new Usuario(8);
		
		arbol.put(usu5.getId(), usu5);
		arbol.put(usu3.getId(), usu3);
		arbol.put(usu7.getId(), usu7);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu4.getId(), usu4);
		arbol.put(usu6.getId(), usu6);
		arbol.put(usu8.getId(), usu8);

		arbol.draw();
		System.out.println("----------------------");
		System.out.println("Altura: " +arbol.getHeight());
					
	}

}
