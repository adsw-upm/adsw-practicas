package es.upm.dit.adsw.p2;

import es.upm.dit.adsw.geosocial.*;

/**
 * 
 * La interfaz Diccionario define un conjunto de m�todos para trabajar con una
 * estructura de datos de diccionario que asocia una clave entera con un objeto
 * Usuario.
 */
public interface Diccionario {

	/**
	 * 
	 * Agrega un objeto Usuario al diccionario, asoci�ndolo con la clave
	 * especificada.
	 * 
	 * @param clave   la clave entera con la que se desea asociar el objeto Usuario
	 * @param usuario el objeto Usuario que se desea agregar al diccionario
	 */
	void put(Integer clave, Usuario usuario);

	/**
	 * 
	 * Retorna el objeto Usuario asociado con la clave especificada.
	 * 
	 * @param clave la clave entera con la que se desea buscar el objeto Usuario
	 * @return el objeto Usuario asociado con la clave especificada, o null si no
	 *         existe una asociaci�n para esa clave
	 */
	Usuario get(Integer clave);

	/**
	 * 
	 * Elimina del diccionario la asociaci�n de clave y objeto Usuario especificada.
	 * 
	 * @param clave la clave entera de la asociaci�n que se desea remover
	 * @return el objeto Usuario que estaba asociado con la clave especificada, o
	 *         null si no exist�a una asociaci�n para esa clave
	 */
	Object remove(Integer clave);

	/**
	 * 
	 * Retorna el n�mero de elementos en el diccionario.
	 * 
	 * @return el n�mero de elementos en el diccionario
	 */
	int size();

	/**
	 * 
	 * Elimina todas las asociaciones de clave y objeto Usuario del diccionario.
	 */
	void clear();
}