/**
La clase ClaveValor representa una asociaci�n de una clave entera con un objeto Usuario.
*/
package es.upm.dit.adsw.p2;
import es.upm.dit.adsw.geosocial.*;

public class CV {
	private final Integer clave;
	private Usuario usuario;

	/**
	 * Constructor de la clase ClaveValor.
	 *
	 * @param clave la clave entera asociada al objeto Usuario
	 * @param usu el objeto Usuario que se desea asociar con la clave
	 */
	public CV(Integer clave, Usuario usu) {
		this.clave = clave;
		this.usuario = usu;
	}

	/**
	 * Retorna la clave asociada a esta instancia de ClaveValor.
	 *
	 * @return la clave entera asociada a este objeto
	 */
	public Integer getClave() {
		return clave;
	}

	/**
	 * Retorna el objeto Usuario asociado a esta instancia de ClaveValor.
	 *
	 * @return el objeto Usuario asociado a este objeto
	 */
	public Usuario getUsuario() {
		return usuario;
	}

	/**
	 * Establece el objeto Usuario asociado a esta instancia de ClaveValor.
	 *
	 * @param usu el nuevo objeto Usuario que se desea asociar con la clave
	 */
	public void setUsuario(Usuario usu) {
		this.usuario = usu;
	}

}