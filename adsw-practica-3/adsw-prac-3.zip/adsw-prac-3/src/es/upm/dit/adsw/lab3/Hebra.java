package es.upm.dit.adsw.lab3;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import es.upm.dit.adsw.interfaces.SegmentoInterface;
import es.upm.dit.adsw.interfaces.MonitorSegmentosInterface;

/**
 * @author aalonso
 * Esta clase define una hebra que debe procesar segmentos. El resultado
 * es una estructura de datos que asocia un actor a las películas en las que
 * ha actuado
 */
public class Hebra extends Thread{

	private MonitorSegmentosInterface monitor;
	private int id;

	public Hebra (MonitorSegmentosInterface monitor, int id) {
		this.monitor = monitor;
		this.id      = id;
	}

	
	/**
	 * Este método es el programa que ejecuta cada hebra
	 * 
	 * Ejecuta en un bucle para procesar los segmentos. Hay que solicitar un segmento,
	 * procesarlo y enviar el resultado. La comunicación es mediante un objeto de 
	 * MonitorSegmentos.
	 * 
	 * Al recibir un segmento hay que comprobar si ha finalizado el procesamiento
	 * de segmentos. 
	 * 
	 * Hay que comprobar si un segmento es null, para no procesarlo. 
	 *
	 */
	public void run() {
		InvertirActores.LOGGER.info("Inicia la hebra " + this.id);
		//TODO alumno
		// Bucle hasta que se detecta el final del monitor (método estaFinalizado)
		//   Obtener un segmento del monitor
		//   Comprobar si es nulo
		//   procesarlo (procesarSegmento)
		//   Enviar el resultado al monitor
	}

	/**
	 * Este método procesa cada segmento. 
	 * @param segmento El segmento a prcesar
	 * @return El resutado al procesar el segmento
	 */
	public HashMap<String, List<Movie>> procesarSegmento(SegmentoInterface segmento) {

		HashMap<String, List<Movie>> invertirActores = new HashMap<String, List<Movie>>();

		// Para cada actor (cast) hay que deteccar las películas en las que han actuado
		// Si ha actuado, incluirlo en la lista
			InvertirActores.LOGGER.finer("Hebra " + this.id + " " + segmento.toString() +
					" resultado " + invertirActores.size());
		return invertirActores;
	}
}

