package es.upm.dit.adsw.interfaces;

/**
 * @author aalonso
 * @since   2022-04-19 
 */

import java.util.List;
import java.util.Map;

import es.upm.dit.adsw.lab3.Movie;

public interface MonitorSegmentosInterface {
	
	

	/**
	 * Un método de la clase `MonitorSegmentos` invoca a este método para proporcionar un segmento.
	 * @param segmento El segmento a procesar
	 * @param id Identificador de la hebra. Se usa para conocer cuáles son las hebras que 
	 * invoca este método en las trazas.
	 */

	public void putSegmento(SegmentoInterface segmento, int id);

	/**
	 * El método `MonitorSegmentos` invoca a este método para obtener un resultado al procesar 
	 * un segmento.
	 * @param id Identificador de la hebra. Se usa para conocer cuáles son las hebras que 
	 * invoca este método en las trazas.
	 * @return El resultado de procesar un segmento
	 * @throws InterruptedException Esta excepción se lanza si se interrumpa a la hebra que ha 
	 * invocado cuando esté bloqueada.
	 */

	public  Map<String, List<Movie>> getResultado(int id) throws InterruptedException;
	/**
	 * Una hebra invoca a este método para obtener un segmento. Este método tiene que 
	 * retornar un `null` si no hay segmentos pendientes de retornar a una hebra y se 
	 * ha finalizado el monitor.
	 * @param id Identificador de la hebra. Se usa para conocer cuáles son las hebras que 
	 * invoca este método en las trazas.
	 * @return El segmento a procesar
	 * @throws InterruptedException Esta excepción se lanza si se interrumpa a la hebra 
	 * que ha invocado cuando esté bloqueada.
	 */

	public  SegmentoInterface getSegmento(int id) throws InterruptedException;

	/**
	 * Una hebra invoca a este método para proporcionar un resultado al procesar un segmento.
	 * @param resultado El resultado
	 * @param id Identificador de la hebra. Se usa para conocer cuáles son las hebras que 
	 * invoca este método en las trazas. 
	 */

	public void putResultado( Map<String, List<Movie>> resultado, int id); 
	/**
	 * El método `MonitorSegmentos` invoca a este método para notificar que ya ha 
	 * obtenido los resultados de los segmentos proporcionados. Este método debe 
	 * activar a las hebras esperando segmentos.
	 */
	public void finalizar();

	/** Las hebras consultan este método para conocer si se ha finalizado el monitor
	 * @return Indica si el  monitor ha finalizado
	 */
	public boolean estaFinalizado();


}

