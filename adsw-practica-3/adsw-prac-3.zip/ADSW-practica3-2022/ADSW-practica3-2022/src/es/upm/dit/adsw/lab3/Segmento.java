package es.upm.dit.adsw.lab3;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import es.upm.dit.adsw.interfaces.SegmentoInterface;

/**
 * @author aalonso
 * Este interface modela un segmento. Gestiona una lista de películas y
 * una estructura de datos que asocia un identificador de una película con una
 * lista de los actores que han actuado.
 */

public class Segmento implements SegmentoInterface, Serializable{

	private static final long serialVersionUID = 1L;
	
	private Map<Integer, List<String>> cast;
	private List<Movie> movies;
	
	public Segmento (Map<Integer, List<String>> aux1, List<Movie> movies) {
		this.cast   = aux1;
		this.movies = movies;
	}

	/**
	 * Genera los segmentos de las películas y elencos, según el número de segmentos 
	 * @param nSegmentos número que se deben generar
	 * @param movies las películas que hay que procesar
	 * @param cast los elecntos que hay que procesar
	 * @return la lista de  los segmentos generados.
	 */
	public static List<SegmentoInterface> generarSegmentos(
			int nSegmentos, List<Movie> movies, Map<Integer, List<String>> cast) {
		int i = movies.size() / nSegmentos;

		ArrayList<SegmentoInterface> segmentos = new ArrayList<SegmentoInterface>();
		
		try {
			for (int j = 0; j <= nSegmentos; j++) {
				Segmento segmento;
				List<Movie> aux = new ArrayList<Movie>();
				Map<Integer, List<String>> aux1 = new HashMap<Integer, List<String>>();
				if (j < nSegmentos) {
					//System.out.println(i * j + " " + (i * (j + 1) - 1));
					//List<Movie> aux =  movies.subList(i * j, i * (j + 1));
					for (int z = i * j; z < i* (j+1); z++) {
						aux.add(movies.get(z));
						int id = movies.get(z).id;
						aux1.put(id, cast.get(id));
					}
				} else {
					//System.out.println(i * j + " " + (movies.size() - 1) );
					//segmentoMovies.add((List<Movie>) movies.subList(i * j, movies.size() - 1));				
					for (int z = i * j; z < movies.size(); z++) {
						aux.add(movies.get(z));
						int id = movies.get(z).id;
						aux1.put(id, cast.get(id));				
					}
				}
				segmento = new Segmento(aux1, aux);
				InvertirActores.LOGGER.finest("Se han generado un segmento"+ segmento.toString());
				segmentos.add(segmento);
			}

			
		}catch(Exception E) {
			InvertirActores.LOGGER.severe(E.toString());
		}
		InvertirActores.LOGGER.info("Se han generado "+ segmentos.size() + " segmentos");
		return segmentos;
	}

	
	public Map<Integer, List<String>> getCast() {
		return this.cast;
	}
	
	public List<Movie> getMovies() {
		return this.movies;
	}

	@Override
	public String toString() {
		return " Tamaño: cast =" + cast.size() + ", movies=" + movies.size() + "]";
	}
	
	
}

