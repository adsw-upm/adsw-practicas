package es.upm.dit.adsw.lab1;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * Interfaz general para GeoServicios en los que se pueden realizar
 * búsquedas entre los usuarios.
 * 
 * El uso principal será en subclases de es.upm.dit.adsw.geosocial.GeoServicio
 * que permitan buscar entre sus usuarios.
 */
public interface Lab1Interface {

	/**
	 * Dado el identificador de un usuario objetivo, devuelve los identificadores de todos los usuarios que coinciden con él.
	 * Dos usuarios coinciden si alguno de los registros del primer usuario coincide con alguno de los registros del
	 * segundo usuario.
	 * 
	 * Dos registros coinciden cuando se han realizado en la misma localización en tiempos cercanos. Esta funcionalidad
	 * ya está desarrollada y se debe reutilizar.
	 * 
	 * @return Conjunto (sin repetición) de identificadores de los usuarios que coinciden con el usuario objetivo. 
	 */
	public Set<Integer> buscarCoincidencias(int id_usuario);

	/**
	 * Devuelve los usuarios que tienen un registro más reciente.
	 * Para ello, se utiliza la lista de registros del almacén, recorriéndola desde el registro más reciente hasta el primer registro.
	 * Antes de utilizar la lista, este método se asegura de que está ordenada.
	 * 
	 * Si un usuario no ha realizado ningún registro, no aparecerá en la lista.
	 * 
	 * @param numero máximo de usuarios a devolver. Si no hay suficientes registros, el tamaño de la lista devuelta puede ser menor.
	 * @return lista con los identificadores de los usuarios, en orden descendente de fecha de último registro.
	 */
	public List<Integer> getUltimos(int numero);

	/**
	 * Dada una fecha, busca los usuarios que tienen un registro en una fecha cercana.
	 * 
	 * El intervalo para la búsqueda será abierto. La lista de usuarios seguirá orden ascendente de fecha de registro.
	 * Si un usuario tiene varios registros en el intervalo, sólo se tendrá en cuenta el primero.  
	 * 
	 * La implementación de este método puede utilizar una estrategia similar a la utilizada en el método anterior (getUltimos),
	 * ordenando los registros antes de la búsqueda.
	 * 
	 * @param fecha alrededor de la cual se van a buscar los registros
	 * @param margen en minutos alrededor de la fecha. Intervalo abierto (no se incluirán tiempos exactamente a esta distancia en minutos)  
	 * @return lista con los identificadores de los usuarios. Sin repetición, en orden ascendente de último registro.
	 */
	public List<Integer> buscarUsuariosPorTiempo(LocalDateTime fecha, int margen);
}
