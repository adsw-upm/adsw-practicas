package es.upm.dit.adsw.p1;

import java.time.LocalDateTime;
import java.util.List;

import es.upm.dit.adsw.geosocial.Registro;
import es.upm.dit.adsw.lab1.Lab1Interface;

/**
 * Interfaz para almacenes que también permiten insertar registros
 * 
 * El uso principal será en subclases de es.upm.dit.adsw.geosocial.GeoAlmacen.
 */
public interface P1Interface extends Lab1Interface {
	/**
	 * Añade un registro a los guardados, manteniendo el orden.
	 * 
	 * El registro se añade tanto a la lista dentro del almacén como al usuario al que corresponda el registro.
	 *
	 * Este método inserta el nuevo registro de forma eficiente. No requiere re-ordenar toda la lista.
	 * Para ello, primero busca la posición en la que se debe insertar el nuevo registro.
	 * 
	 * @param registro Registro a insertar en el almacén
	 * @return índice del registro en la lista de registros del almacén
	 */
	public int insertaRegistro(Registro registro);

	/**
	 * Busca registros cercanos a una fecha dada. Este método funciona de forma análoga al método 
	 * 
	 * @param fecha 
	 * @return
	 */
	public List<Registro> buscarRegistrosPorTiempo(LocalDateTime fecha, int margen);
	
}
