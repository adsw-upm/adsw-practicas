package es.upm.dit.adsw.p1;

import static org.junit.jupiter.api.Assertions.*;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.Timeout;

import es.upm.dit.adsw.geosocial.Localizacion;
import es.upm.dit.adsw.geosocial.Registro;
import es.upm.dit.adsw.geosocial.Usuario;
import es.upm.dit.adsw.lab1.AlmacenLab1;
import es.upm.dit.adsw.lab1.Lab1Interface;

@TestMethodOrder(OrderAnnotation.class)
class TestsFuncionales {
	/**
	 * Comprueba que se puede crear un AlmacenLab1
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@SuppressWarnings("unused")
	@Test
	@Order(1)
	void test1_Constructor() throws FileNotFoundException, ParseException {
		AlmacenLab1 almacen1 = new AlmacenP1(Arrays.asList(new Usuario(0), new Usuario(1)));
		assertEquals(2, almacen1.getNUsuarios());
		AlmacenLab1 casting = almacen1; // Esto fallará si no se implementa el interfaz
	}
	
	/**
	 * Comprueba que se puede crear un AlmacenLab1 desde un fichero de localizaciones
	 */
	@Test
	@Order(2)
	void test2_ConstructorFichero() throws FileNotFoundException, ParseException {
		AlmacenLab1 almacen = new AlmacenP1("data/locations10.tsv");
		assertEquals(10, almacen.getNUsuarios());
		assertEquals(1392, almacen.getNRegistros());
		List<Registro> registros = almacen.getRegistros();
		for(int i=1; i < registros.size(); i++) {
			assertTrue(registros.get(i).getFecha().isAfter(registros.get(i-1).getFecha()));
		}
	}
	
	
	/**
	 * Comprueba que se insertan bien nuevos registros
	 * @throws FileNotFoundException si el fichero no existe
	 * @throws ParseException si el fichero no tiene el formato adecuado
	 */
	@Test	
	@Timeout(1)
	@Order(3)
	void test3_Insertar() throws FileNotFoundException, ParseException {
		AlmacenP1 ranked = new AlmacenP1("data/locations10.tsv");
		
		// Probamos a reinsertar todos los registros ya existentes
		List<Registro> registros = new ArrayList<Registro>(ranked.getRegistros());
		assertTrue(registros.size() > 0);
		for(Registro reg: registros) {
			int s = ranked.getNRegistros();
			ranked.insertaRegistro(reg);
			assertEquals(ranked.getNRegistros(), s + 1);
		}
		
		assertEquals(registros.size()*2, ranked.getNRegistros());
		
		registros = ranked.getRegistros();
		
		for(int i=1; i<registros.size(); i++) {
			LocalDateTime f1 = registros.get(i-1).getFecha();
			LocalDateTime f2 = registros.get(i).getFecha();
			assertTrue(!f1.isAfter(f2));
		}
	}
	
	/**
	 * Comprueba que el método buscarUsuariosPorTiempo funciona para un caso simple, con 3 usuarios, y 3 tiempos diferentes.
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	@Order(4)
	void test4_BusquedaTiempoManual() throws FileNotFoundException, ParseException {
		Usuario u1 = new Usuario(1);
		Localizacion loc1 = new Localizacion(0, 100);
		LocalDateTime ahora = LocalDateTime.now();
		LocalDateTime en1 = ahora.plusMinutes(1);
		LocalDateTime en5 = ahora.plusMinutes(5);
		
		Registro reg1 = new Registro(1, ahora, loc1);
		u1.registrar(reg1);
		Registro reg2 = new Registro(1, en1, loc1);
		u1.registrar(reg1);
		Registro reg3 = new Registro(1, en5, loc1);
		u1.registrar(reg1);
		

		P1Interface servicio = new AlmacenP1(Arrays.asList(u1));
		List<Registro> listaAhora = servicio.buscarRegistrosPorTiempo(ahora, 1);
		List<Registro> listaEn5 = servicio.buscarRegistrosPorTiempo(en5, 5);
		
		assertEquals(Arrays.asList(reg1), listaAhora);
		assertEquals(Arrays.asList(reg3), listaEn5);
	}


	
	/**
	 * Comprueba que un caso sencillo de coincidencia funciona.
	 * Se añaden tres usuarios, dos de ellos tienen una coincidencia.
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	@Order(5)
	void test5_CoincidentesManual() throws FileNotFoundException, ParseException {
		Usuario u1 = new Usuario(1);
		Usuario u2 = new Usuario(2);
		Usuario u3 = new Usuario(3);
		u1.registrar(new Localizacion(10, 0));
		u2.registrar(new Localizacion(10, 0));
		AlmacenLab1 gestor = new AlmacenP1(Arrays.asList(u1, u2, u3));
		Set<Integer> coinciden = gestor.buscarCoincidencias(u1.getId());
		assertEquals(1, coinciden.size());
		coinciden = gestor.buscarCoincidencias(u2.getId());
		assertEquals(1, coinciden.size());
		assertEquals(0, gestor.buscarCoincidencias(u3.getId()).size());
	}
	
	/**
	 * Comprueba que tres casos de los que sabemos el resultado esperado funcionan.
	 * 
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	@Order(6)
	void test6_Coincidentes() throws FileNotFoundException, ParseException {
		AlmacenLab1 ranked = new AlmacenP1("data/locations10.tsv");
		assertEquals(1, ranked.buscarCoincidencias(5496).size());
		assertEquals(0, ranked.buscarCoincidencias(42).size());
		assertEquals(1, ranked.buscarCoincidencias(4223).size());
	}
	

	@Test
	@Timeout(value=1)
	@Order(7)
	void test7_CoincidentesComplejidad() throws FileNotFoundException, ParseException {
		AlmacenLab1 almacen = new AlmacenP1("data/locations100.tsv");

		for(int i=0; i<10; i++) {
			assertEquals(0, almacen.buscarCoincidencias(30865).size());
			assertEquals(1, almacen.buscarCoincidencias(5496).size());
		}
	}

	
}
