package es.upm.dit.moodle.evaluation.server.moodle.client;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.cert.CertificateParsingException;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import es.upm.dit.moodle.evaluation.server.curl.JCurl;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleObject.MoodleJsonException;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleRequest.HttpCallException;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleUpdate.FileUpdate;

public class MoodleUser extends MoodleObject {

	protected MoodleUser(JSONObject obj) {
		super(obj);
	}

	public Integer getId() {
		return (Integer) attributes.get("id");
	}

	public String getEmail() {
		return (String) attributes.get("email");
	}
	
	public static String getToken(String login, String passwd, String domain) {
		try {
			JCurl jcurl = JCurl.builder()
				    .method(JCurl.HttpMethod.POST)
				    .build();
			String elogin=URLParamEncoder.encode(login);
			String epasswd=URLParamEncoder.encode(passwd);
			HttpURLConnection connection = jcurl.connect(domain+"login/token.php?username="+elogin+"&password="+epasswd+"&service=moodle_mobile_app");
			JSONObject response=new JSONObject(jcurl.processResponse(connection).getOutput());
			String token=response.getString("token");
			if (token == null || token.length() == 0)
				throw new MoodleJsonException();
			return token;
		} catch (IOException e) {
			throw new HttpCallException(e);
		} catch (CertificateParsingException e) {
			throw new HttpCallException(e);
		} catch (JSONException e) {
			throw new MoodleJsonException("Moodle no permiter hacer login a: "+login);
		}

	}
	
	public static String getUsername(String token) {
		JCurl jcurl2 = JCurl.builder()
			    .method(JCurl.HttpMethod.POST)
			    .build();
		HttpURLConnection connection;
		try {
			connection = jcurl2.connect(MoodleCourse.MoodleCourseBuilder.instance(token).getDomainName()+"webservice/rest/server.php?wsfunction=core_webservice_get_site_info&moodlewsrestformat=json&wstoken="+token);
			JSONObject result=new JSONObject(jcurl2.processResponse(connection).getOutput());
			return result.getString("username");
		} catch (IOException e) {
			throw new HttpCallException(e);
		} catch (CertificateParsingException e) {
			throw new HttpCallException(e);
		} catch (JSONException e) {
			throw new MoodleJsonException("Error recuperando login de usuario");
		}
	}
	
	public static String getUseremail(String token) {
		JCurl jcurl2 = JCurl.builder()
			    .method(JCurl.HttpMethod.POST)
			    .build();
		HttpURLConnection connection;
		try {
			connection = jcurl2.connect(MoodleCourse.MoodleCourseBuilder.instance(token).getDomainName()+"webservice/rest/server.php?wsfunction=core_webservice_get_site_info&moodlewsrestformat=json&wstoken="+token);
			JSONObject result=new JSONObject(jcurl2.processResponse(connection).getOutput());
			int id=result.getInt("userid");
			jcurl2 = JCurl.builder()
				    .method(JCurl.HttpMethod.POST)
				    .build();
			connection = jcurl2.connect(MoodleCourse.MoodleCourseBuilder.instance(token).getDomainName()+"webservice/rest/server.php?wsfunction=core_user_get_users_by_field&field=id&values%5B0%5D="+id+"&moodlewsrestformat=json&wstoken="+token);
			JSONArray result2 = new JSONArray(jcurl2.processResponse(connection).getOutput());
			return ((JSONObject) result2.get(0)).getString("email");
		} catch (IOException e) {
			throw new HttpCallException(e);
		} catch (CertificateParsingException e) {
			throw new HttpCallException(e);
		} catch (JSONException e) {
			throw new MoodleJsonException("Error recuperando login de usuario");
		}
	}
	
    public static class URLParamEncoder {

        public static String encode(String input) {
            StringBuilder resultStr = new StringBuilder();
            for (char ch : input.toCharArray()) {
                if (isUnsafe(ch)) {
                    resultStr.append('%');
                    resultStr.append(toHex(ch / 16));
                    resultStr.append(toHex(ch % 16));
                } else {
                    resultStr.append(ch);
                }
            }
            return resultStr.toString();
        }

        private static char toHex(int ch) {
            return (char) (ch < 10 ? '0' + ch : 'A' + ch - 10);
        }

        private static boolean isUnsafe(char ch) {
            if (ch > 128 || ch < 0)
                return true;
            return " %$&+,/:;=?@<>#%".indexOf(ch) >= 0;
        }

    }
}
