package es.upm.dit.moodle.evaluation.server.moodle.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import es.upm.dit.moodle.evaluation.server.curl.JCurl;

public class MoodleRequest {

    protected String token;
    public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	public static final String DOMAIN_DEFAULT="https://moodle.upm.es/titulaciones/oficiales/";

	private String domainName = DOMAIN_DEFAULT;

    public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	protected MoodleRequest(String domain, String token) {
    	this.token=token;
    	this.domainName=domain;
    }
    
    protected MoodleRequest(String token) {
    	this.token=token;
    }
    
    protected String call(String protocol, String wsFunction, String params) {
    	HttpURLConnection connection=null;
    	URL getUrl=null;
        try {
        	/*
            getUrl = new URL(domainName+"webservice/rest/server.php?wstoken="+token+"&wsfunction="+wsFunction+params+"&moodlewsrestformat=json");
            connection = (HttpURLConnection)getUrl.openConnection();
            connection.setRequestMethod(protocol);
            connection.setRequestProperty("Accept", "application/json");	
            StringBuilder buffer=new StringBuilder();
            BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line=reader.readLine())!=null) {
            	if (!line.equals("null"))
            		buffer.append(line).append('\n');
            }
            return buffer.toString();
            */
        	JCurl jcurl = JCurl.builder()
				    .method(JCurl.HttpMethod.POST)
				    .build();

			connection = jcurl.connect(domainName+"webservice/rest/server.php?wstoken="+token+"&wsfunction="+wsFunction+params+"&moodlewsrestformat=json");

			JCurl.Response response = jcurl.processResponse(connection);
			return response.getOutput();
        } catch (Throwable t) {
        		throw new HttpCallException("Http call error to "+domainName+": "+t.toString());// +" calling "+(connection != null ? connection.getURL() : getUrl.toString()));
        }
    }
    
    public static class HttpCallException extends RuntimeException {
	    	public HttpCallException(Throwable t) {
	    		super(t);
	    	}
	    	public HttpCallException() {
	    		super();
	    	}
	    	public HttpCallException(String msg) {
	    		super(msg);
	    	}
    }
}
