package es.upm.dit.moodle.evaluation.server.moodle.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MoodleCourse extends MoodleObject {

	private List<MoodleContent> contents;
	private List<MoodleUser> users;
	private List<MoodleAssignment> assignments;
	private String courseId;
	private String token;
	
	protected MoodleCourse(String courseId, String token) {
		super();
		this.token=token;
		this.courseId=courseId;
		attributes.put("id", courseId);
	}
	public List<MoodleContent> getContents() {
		if (contents == null)
			contents=new ArrayList<MoodleContent>();
		MoodleCourseBuilder.instance(token).build(this);
		return contents;
	}
	public List<MoodleUser> getUsers() {
		if (users == null)
			users=new ArrayList<MoodleUser>();
		MoodleCourseBuilder.instance(token).buildUsers(this);
		return users;
	}
	public List<MoodleAssignment> getAssignment() {
		if (assignments == null)
			assignments=new ArrayList<MoodleAssignment>();
		MoodleCourseBuilder.instance(token).buildAssignments(this);
		return assignments;
	}
	public MoodleAssignment getAssignment(String name) {
		for (MoodleAssignment ass : getAssignment())
			if (ass.getName().equals(name))
				return ass;
		return null;
	}
	public MoodleUser getUser(String uname) {
		for (MoodleUser user : getUsers()) {
			String email=user.getEmail();
			if (email != null && email.equals(uname))
				return user;
		}
		return null;
	}
	public static class MoodleCourseBuilder extends MoodleRequest {
		public MoodleCourseBuilder(String domain, String token) {
			super(domain,token);
		}
		public MoodleCourseBuilder(String token) {
			super(token);
		}
		private static MoodleCourseBuilder pinstance=null;
		public static MoodleCourseBuilder instance(String token) {
			if (pinstance == null)
				pinstance=new MoodleCourseBuilder(token);
			else
				if (!pinstance.token.equals(token))
					pinstance=new MoodleCourseBuilder(token);
			return pinstance; 
		}
		public MoodleCourse build(String courseId,String token) throws HttpCallException {
			String params="&courseid="+courseId;
			String response=call("POST","core_course_get_contents",params);
			MoodleCourse course=new MoodleCourse(courseId,token);
			course.contents=new ArrayList<MoodleContent>();

			JSONArray array;
			try {
				array=new JSONArray(response);
				for (Iterator<Object> ite=array.iterator(); ite.hasNext();) {
					Object obj=ite.next();
					if (!(obj instanceof JSONObject))
						throw new MoodleJsonException();
					course.contents.add(new MoodleContent((JSONObject) obj));
				}
			} catch(JSONException ex) {
				throw new MoodleJsonException("Error localizando el curso ("+courseId+") en moodle");
			}
			return course;
		}
		public void build(MoodleCourse course) throws HttpCallException {
			String params="&courseid="+course.courseId;
			String response=call("POST","core_course_get_contents",params);
			JSONArray array;
			try {
				array=new JSONArray(response);
				course.contents.clear();
				for (Iterator<Object> ite=array.iterator(); ite.hasNext();) {
					Object obj=ite.next();
					if (!(obj instanceof JSONObject))
						throw new MoodleJsonException();
					course.contents.add(new MoodleContent((JSONObject) obj));
				}
			} catch(JSONException ex) {
				throw new MoodleJsonException("Error localizando el curso ("+course.courseId+") en moodle");
			}
		}
		public void buildUsers(MoodleCourse course) throws HttpCallException {
			String params="&courseid="+course.courseId;
			String response=call("POST","core_enrol_get_enrolled_users",params);
			JSONArray array;
			try {
				array=new JSONArray(response);
				course.users.clear();
				for (Iterator<Object> ite=array.iterator(); ite.hasNext();) {
					Object obj=ite.next();
					if (!(obj instanceof JSONObject))
						throw new MoodleJsonException();
					course.users.add(new MoodleUser((JSONObject) obj));
				}
			} catch(JSONException ex) {
				throw new MoodleJsonException("Error localizando usuarios del curso ("+course.courseId+") en moodle");
			}
		}
		public void buildAssignments(MoodleCourse course) throws HttpCallException {
			String params="&courseids[0]="+course.courseId;
			String response=call("POST","mod_assign_get_assignments",params);
			try {
				JSONObject courses=new JSONObject(response);
				JSONArray coursea=courses.getJSONArray("courses");
				if (coursea.isEmpty())
					throw new MoodleJsonException();
				JSONObject courseo=coursea.getJSONObject(0);
				if (!(courseo.get("assignments") instanceof JSONArray))
					throw new MoodleJsonException();
				JSONArray array=courseo.getJSONArray("assignments");
				course.assignments.clear();
				for (Iterator<Object> ite=array.iterator(); ite.hasNext();) {
					Object obj=ite.next();
					if (!(obj instanceof JSONObject))
						throw new MoodleJsonException();
					course.assignments.add(new MoodleAssignment((JSONObject) obj,course.token));
				}
			} catch(JSONException ex) {
				throw new MoodleJsonException("Error localizando tareas del curso ("+course.courseId+") en moodle");
			}
		}
	}
}
