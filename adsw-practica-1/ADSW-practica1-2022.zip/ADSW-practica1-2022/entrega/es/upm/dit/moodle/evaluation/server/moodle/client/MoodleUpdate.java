package es.upm.dit.moodle.evaluation.server.moodle.client;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import es.upm.dit.moodle.evaluation.server.curl.JCurl;

public class MoodleUpdate {

	private String token;
	private String domainName = MoodleRequest.DOMAIN_DEFAULT;

	public MoodleUpdate(String domain, String token) {
	    this.token=token;
	    this.domainName=domain;
	}
	
    public MoodleUpdate(String token) {
    	this.token=token;
    }
    
    private static final String CRLF = "\r\n";
    
    protected FileUpdate[] call(String fileName, String filePath, String fileArea) {
    	JCurl.Response response;
		try {
			JCurl jcurl = JCurl.builder()
				    .method(JCurl.HttpMethod.POST)
				    .form("name", fileName)
				    .form("filearea", fileArea)
				    .form("filedata", "@"+filePath)
				    .build();

			HttpURLConnection connection;
			connection = jcurl.connect(domainName+"webservice/upload.php?token="+token);
			response = jcurl.processResponse(connection);
        } catch (Throwable t) {
        		throw new MoodleRequest.HttpCallException(t);
        }
		FileUpdate[] fu=null;
		try {
			JSONArray files=new JSONArray(response.getOutput());
			fu=new FileUpdate[files.length()];
			for (int i=0; i < files.length(); i++) {
				fu[i]=new FileUpdate(files.getJSONObject(i));
			}
		} catch(JSONException ex) {
			throw new MoodleObject.MoodleJsonException();
		}
		return fu;
    }
    
    private static final char[] hexArray = "0123456789ABCDEF".toCharArray();
    
	private StringBuffer byte2ASCIIHex(byte[] data) {
    	StringBuffer sb = new StringBuffer();
    	int i=0;
    	for (byte b : data) {
    		int v = b & 0xFF;
	    char high = hexArray[v / 0x10];
	    char low = hexArray[v & 0x0F];
    		sb.append(high);
    		sb.append(low);
    		i=(i+1)%020;
    		if (i == 0)
    			sb.append(CRLF);
    	}
    	if (i != 0)
    		sb.append(CRLF);
    	return sb;
	}
	
	public FileUpdate[] doCall(String fileName, String filePath, String fileArea) throws MoodleRequest.HttpCallException {
		return call(fileName,filePath, fileArea);
	}
	
	public static class FileUpdate extends MoodleObject {
		public FileUpdate(JSONObject json) {
			super(json);
		}
	}
}
