package es.upm.dit.moodle.evaluation.server.moodle.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class MoodleContent extends MoodleObject {

	protected MoodleContent(JSONObject obj) {
		super(obj);
	}

	public List<MoodleModule> getModules() {
		Object moduleAtr=getAttributes().get("modules");
		List<MoodleModule> modules=new ArrayList<MoodleModule>();
		if (!(moduleAtr instanceof JSONArray))
			throw new MoodleJsonException();
		for (Iterator<Object> ite=((JSONArray) moduleAtr).iterator(); ite.hasNext(); ) {
			Object module=ite.next();
			if (!(module instanceof JSONObject))
				throw new MoodleJsonException();
			modules.add(new MoodleModule((JSONObject) module));
		}
		return modules;
	}
}
