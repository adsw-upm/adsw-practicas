package es.upm.dit.moodle.evaluation.server.moodle.client;

import org.json.JSONObject;

public class MoodleModule extends MoodleObject {

	protected MoodleModule(JSONObject obj) {
		super(obj);
	}
}
