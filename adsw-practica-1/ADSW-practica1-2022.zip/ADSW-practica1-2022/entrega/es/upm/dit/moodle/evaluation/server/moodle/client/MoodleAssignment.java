package es.upm.dit.moodle.evaluation.server.moodle.client;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.cert.CertificateParsingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import es.upm.dit.moodle.evaluation.server.curl.JCurl;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleCourse.MoodleCourseBuilder;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleObject.MoodleJsonException;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleRequest.HttpCallException;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleUpdate.FileUpdate;

public class MoodleAssignment extends MoodleObject {

	private List<MoodleGrade> grades=null;
	private String token;
	
	protected MoodleAssignment(JSONObject obj, String token) {
		super(obj);
		this.token=token;
	}
	
	public String getCourseId() {
		return (String) attributes.get("course");
	}
	public Integer getId() {
		return (Integer) attributes.get("id");
	}
	public String getName() {
		return (String) attributes.get("name");
	}
	public void setUserGrade(String userid,String grade, String comment,boolean doLock) {
		MoodleAssignmentBuilder.instance(token).setGrade(this,userid,grade,comment,doLock);
	}
	public List<MoodleGrade> getGrades() {
		if (grades != null)
			return grades;
		grades=new ArrayList<MoodleGrade>();
		MoodleAssignmentBuilder.instance(token).buildGrades(this);
		return grades;
	}
	public void unlockAssignment(String userid,String comment) {
		MoodleAssignmentBuilder.instance(token).unlockAssignment(this,userid,comment);
	}
	public JSONArray saveUserSubmission(String userToken, String fileName, String filePath) {
		JCurl jcurl2 = JCurl.builder()
			    .method(JCurl.HttpMethod.POST)
			    .build();
		FileUpdate[] fu=new MoodleUpdate(MoodleCourse.MoodleCourseBuilder.instance(userToken).getDomainName(),userToken).doCall(fileName, filePath, "draft");
		Integer draftfileid=(Integer) fu[0].getAttributes().get("itemid");
		HttpURLConnection connection;
		try {
			connection = jcurl2.connect(MoodleCourse.MoodleCourseBuilder.instance(userToken).getDomainName()+"webservice/rest/server.php?wsfunction=mod_assign_save_submission&moodlewsrestformat=json&wstoken="+userToken+"&assignmentid="+getId()+"&plugindata[onlinetext_editor][text]=sometext&plugindata[onlinetext_editor][format]=1&plugindata[onlinetext_editor][itemid]="+draftfileid+"&plugindata[files_filemanager]="+draftfileid);
			return new JSONArray(jcurl2.processResponse(connection).getOutput());
		} catch (IOException e) {
			throw new HttpCallException(e);
		} catch (CertificateParsingException e) {
			throw new HttpCallException(e);
		} catch (JSONException e) {
			throw new MoodleJsonException("Error salvando fichero en moodle");
		}
	}
	public int getLastSubmissionTime(String userToken) {
		MoodleAssignmentBuilder user=new MoodleAssignmentBuilder(userToken);
		return user.buildLastSubmissionTime(this);
	}
	public static class MoodleAssignmentBuilder extends MoodleRequest {
		public MoodleAssignmentBuilder(String token) {
			super(token);
		}
		public int buildLastSubmissionTime(MoodleAssignment assignment) {
			String params="&assignid="+assignment.getId();
			String response=call("POST","mod_assign_get_submission_status",params);
			try {
				JSONObject status=new JSONObject(response);
				JSONObject lastattempt=status.getJSONObject("lastattempt");
				JSONObject submission=lastattempt.getJSONObject("submission");
				JSONArray plugins=submission.getJSONArray("plugins");
				if (plugins.isEmpty())
					throw new MoodleJsonException();
				JSONObject pluginso=plugins.getJSONObject(0);
				if (!(pluginso.get("fileareas") instanceof JSONArray))
					throw new MoodleJsonException();
				JSONArray fileareas=pluginso.getJSONArray("fileareas");
				JSONObject fileareaso=fileareas.getJSONObject(0);
				if (!(fileareaso.get("files") instanceof JSONArray))
					throw new MoodleJsonException();
				JSONArray files=fileareaso.getJSONArray("files");
				JSONObject fileso=files.getJSONObject(0);
				Integer time=(Integer) fileso.get("timemodified");
				return time;
			} catch(JSONException ex) {
				throw new MoodleJsonException();
			}
		}
		private static MoodleAssignmentBuilder pinstance=null;
		public static MoodleAssignmentBuilder instance(String token) {
			if (pinstance == null)
				pinstance=new MoodleAssignmentBuilder(token);
			return pinstance; 
		}

		public void buildGrades(MoodleAssignment assignment) throws HttpCallException {
			String params="&assignmentids[0]="+assignment.getId();
			String response=call("POST","mod_assign_get_grades",params);
			try {
				JSONObject grades=new JSONObject(response);
				JSONArray assigments=grades.getJSONArray("assignments");
				if (assigments.isEmpty())
					throw new MoodleJsonException();
				JSONObject assigmento=assigments.getJSONObject(0);
				if (!(assigmento.get("grades") instanceof JSONArray))
					throw new MoodleJsonException();
				JSONArray array=assigmento.getJSONArray("grades");
				assignment.grades.clear();
				for (Iterator<Object> ite=array.iterator(); ite.hasNext();) {
					Object obj=ite.next();
					if (!(obj instanceof JSONObject))
						throw new MoodleJsonException();
					assignment.grades.add(new MoodleGrade((JSONObject) obj));
				}
			} catch(JSONException ex) {
				throw new MoodleJsonException();
			}
		}
		public void setGrade(MoodleAssignment assignment,String userid,String grade, String comment, boolean doLock) throws HttpCallException {
			if (comment == null || comment.length() == 0)
				comment="Sin-comentarios";
			if (grade == null || grade.length() == 0)
				throw new MoodleJsonException("Error al registrar una nota erronea");
			String params="&assignmentid="+assignment.getId()+"&userid="+userid+"&grade="+grade+"&attemptnumber=-1&addattempt=1&workflowstate=released&applytoall=0&plugindata[assignfeedbackcomments_editor][text]="+comment+"&plugindata[assignfeedbackcomments_editor][format]=2&plugindata[files_filemanager]=0";
			try {
				String response=call("GET","mod_assign_save_grade",params);
				if (response != null && response.length() > 0 && !response.equals("\n") && !response.startsWith("null")) {
					try {
						JSONObject exception=new JSONObject(response);
						throw new MoodleJsonException("Moodle devuelve errores al registrar la nota: "+exception.get("exception"));
					} catch (JSONException ex) {}
					throw new MoodleJsonException("Moodle devuelve errores al registrar la nota. ");
				}
				if (doLock) {
					params="&assignmentid="+assignment.getId()+"&userids[0]="+userid;
					response=call("GET","mod_assign_lock_submissions",params);
					JSONArray array=new JSONArray(response);
					if (!array.isEmpty()) {
						try {
							String warning=(String) array.get(0);
							throw new MoodleJsonException("Moodle devuelve errores al bloquear entrega "+warning);
						} catch (JSONException ex) {}
						throw new MoodleJsonException("Moodle devuelve errores al bloquear entrega. ");
					}

				}
			} catch(JSONException ex) {
				throw new MoodleJsonException(ex.getMessage());
			}
		}
		public void unlockAssignment(MoodleAssignment assignment,String userid, String comment) throws HttpCallException {
			if (comment == null || comment.length() == 0)
				comment="Sin-comentarios";
			String params="&assignmentid="+assignment.getId()+"&userids[0]="+userid;
			try {
				String response=call("GET","mod_assign_unlock_submissions",params);
				JSONArray array=new JSONArray(response);
				if (!array.isEmpty()) {
					try {
						String warning=(String) array.get(0);
						throw new MoodleJsonException("Moodle devuelve errores al desbloquear entrega "+warning);
					} catch (JSONException ex) {}
					throw new MoodleJsonException("Moodle devuelve errores al desbloquear entrega. ");
				}
			} catch(JSONException ex) {
				throw new MoodleJsonException(ex.getMessage());
			}
		}
	}
}
