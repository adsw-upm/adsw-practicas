package es.upm.dit.moodle.evaluation.server.moodle.client;

import org.json.JSONObject;

public class MoodleGrade extends MoodleObject {

	protected MoodleGrade(JSONObject obj) {
		super(obj);
	}
}
