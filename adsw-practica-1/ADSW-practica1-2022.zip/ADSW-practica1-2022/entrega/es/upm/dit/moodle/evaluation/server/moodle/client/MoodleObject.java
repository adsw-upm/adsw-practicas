package es.upm.dit.moodle.evaluation.server.moodle.client;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

public class MoodleObject {

	protected MoodleObject() {
		
	}
	protected MoodleObject(JSONObject obj) {
		for (String key : obj.keySet())
			attributes.put(key, obj.get(key));
	}
	protected Map<String,Object> attributes=new HashMap<String,Object>();

	public Map<String,Object> getAttributes() {
		return attributes;
	}
	
	public static class MoodleJsonException extends RuntimeException {
		
		public MoodleJsonException() {
			super();
		}
		
		public MoodleJsonException(String msg) {
			super(msg);
		}
	}
}
