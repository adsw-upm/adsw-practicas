import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import es.upm.dit.adsw.movies.Movie;
import es.upm.dit.adsw.movies.MovieSorter;
import es.upm.dit.adsw.movies.Recommender;
import es.upm.dit.adsw.p1.ej1.DefaultSorter;
import es.upm.dit.adsw.p1.ej2.DefaultRecommender;
import es.upm.dit.adsw.p1.ej3.LanguageRecommender;


/**
 * Conjunto de pruebas para las clases del paquete es.upm.dit.adsw.movies.p1
 *
 */
public class Corrector {

	private static List<Movie> lista_original;
	private List<Movie> peliculas;
	long t;
	
	// Originalmente era un 2. Lo he subido porque fallaban algunos timeouts básicos a veces.
	final long timeoutScale = 4;

	@BeforeClass
	public static void cargaPeliculas() {
		System.out.println("Running carga");
		try {
			lista_original = Movie.allFromFile("data/metadata.tsv");
		} catch(Throwable e) {
    		fail("Error cargando fichero con allFromFile");
    	}
	}
	
	@Before
	public void setUp() {
		this.peliculas = new ArrayList<Movie>(lista_original);
	}

	@Test
	public void testEj1_compare() {


		Movie m1 = peliculas.get(0);
		Movie m2 = peliculas.get(1);

		// Testing Movie.compareTo
		assertTrue(m1.compareTo(m2) > 0);
		assertTrue(m1.compareTo(m1) == 0);
		
		Movie m4 = peliculas.get(4);
		Movie m5 = peliculas.get(5);

		
		assertTrue(m4.compareTo(m5) < 0);
		assertTrue(m4.compareTo(m4) == 0);
		assertTrue(m5.compareTo(m5) == 0);
	}
	
	@Test
	public void testEj1_sort() {
		final Movie[] array = new Movie[peliculas.size()];
		peliculas.toArray(array);

		// Testing DefaultSorter
		MovieSorter sorter = new DefaultSorter();

		sorter.sort(array);

		for (int i = 1; i < array.length; i++) {
			assert array[i - 1].getPopularity() - array[i].getPopularity() >= 0;
		}

		// Testing timeout
		peliculas.toArray(array);
		t = System.currentTimeMillis();
		Arrays.sort(array);
		t = System.currentTimeMillis() - t;
		peliculas.toArray(array);
		assertTimeoutPreemptively(Duration.ofMillis(t * timeoutScale), () -> {
			sorter.sort(array);
		});


		// Testing timeout with reversed array
		peliculas.toArray(array);
		Collections.reverse(Arrays.asList(array));
		t = System.currentTimeMillis();
		Arrays.sort(array);
		t = System.currentTimeMillis() - t;
		
		peliculas.toArray(array);
		Collections.reverse(Arrays.asList(array));
		assertTimeoutPreemptively(Duration.ofMillis(t * timeoutScale), () -> {
			sorter.sort(array);
		});
	}

	@Test (timeout=2000)
	public void testEj2Tamanyos() throws FileNotFoundException {

		Recommender recomender = new DefaultRecommender(this.peliculas);

		Comparator<Movie> comparatorPopReversed = new BaselineComparator();

		// Testing list sizes
		assertEquals(0, recomender.recommend(0).size());
		assertEquals(10, recomender.recommend(10).size());
		assertEquals(0, recomender.recommend(0, "en").size());
		assertEquals(10, recomender.recommend(10, "en").size());
		assertEquals(peliculas.size(), recomender.recommend(1000000).size());
		assertEquals(peliculas.stream().filter(s -> s.getOriginalLanguage().equals("en")).count(),
				recomender.recommend(1000000, "en").size());
	}
	
	@Test (timeout=2000)
	public void testEj2Contenidos() throws FileNotFoundException {
		Recommender recomender = new DefaultRecommender(this.peliculas);
		Comparator<Movie> comparatorPopReversed = new BaselineComparator();

		// Testing list contents
		assertEquals(peliculas.stream().sorted(comparatorPopReversed).limit(10).collect(Collectors.toList()).toString(),
				recomender.recommend(10).toString());
		assertEquals(peliculas.stream().filter(s -> s.getOriginalLanguage().equals("en")).sorted(comparatorPopReversed)
				.limit(10).collect(Collectors.toList()).toString(), recomender.recommend(10, "en").toString());
		assertEquals(peliculas.stream().filter(s -> s.getOriginalLanguage().equals("es")).sorted(comparatorPopReversed)
				.limit(10).collect(Collectors.toList()).toString(), recomender.recommend(10, "es").toString());
	}
	
	@Test (timeout=2000)
	public void testEj3Tamanyos() throws Exception {
		Recommender recommender = new LanguageRecommender(this.peliculas);
		Recommender baseline = new BaselineLanguageRecommender(this.peliculas);


		// Testing list sizes
		assertEquals(0, recommender.recommend(0).size());
		assertEquals(1000, recommender.recommend(1000).size());
	}
		
	@Test (timeout=2000)
	public void testEj3Contenidos() throws Exception {
		Recommender recommender = new LanguageRecommender(this.peliculas);
		Recommender baseline = new BaselineLanguageRecommender(this.peliculas);
		
		// Testing list contents
		assertEquals(
				baseline.recommend(1000).toString(),
				recommender.recommend(1000).toString());
		assertEquals(
				baseline.recommend(100, "es").toString(),
				recommender.recommend(100, "es").toString());
	}

	@Test (timeout=2000)
	public void testEj3_0_TiemposEn() throws FileNotFoundException {
		Map<String, Double> scales = new HashMap<String, Double>();
		scales.put("en", 0.5);
		this.pruebas_ej3_idioma(scales);

	}
	

	@Test (timeout=2000)
	public void testEj3_1_TiemposES() throws FileNotFoundException {
		Map<String, Double> scales = new HashMap<String, Double>();
		scales.put("es", 0.1);
		this.pruebas_ej3_idioma(scales);
	}

	@Test (timeout=2000)
	public void testEj3_2_TiemposOtrosIdiomas() throws FileNotFoundException {
		Map<String, Double> scales = new HashMap<String, Double>();
		// El idioma no existe, así que sólo debería hacer una pasada.
		scales.put("fr", 0.1);
		scales.put("de", 0.1);
		this.pruebas_ej3_idioma(scales);
	}
	
	@Test (timeout=2000)
	public void testEj3_3_TiemposIdiomaInventado() throws FileNotFoundException {
		Map<String, Double> scales = new HashMap<String, Double>();
		// El idioma no existe, así que sólo debería hacer una pasada.
		scales.put("inventado", 0.1);
		this.pruebas_ej3_idioma(scales);
	}

	void pruebas_ej3_idioma(Map<String, Double> scales) {
		Recommender baseline = new BaselineLanguageRecommender(this.peliculas);

		// Testing timeouts
		// Try 10 calls to check if they sort the collection
		// Para tamaños pequeños de entrada el método debería ser mucho más rápido que el baseline, porque no tiene que reordenar todos los elementos.

		
		// Con el método naif, se ordena TODO el array.
		// Con el método propuesto, se hace un merge.
		int nIters = 20;
		int nElems = 10;
		for(String lang: scales.keySet()) {
			System.out.println("Comprobando las recomendaciones para el idioma '" + lang + "'");
			
			Recommender recommender2 = new LanguageRecommender(this.peliculas);

			assertEquals(
					baseline.recommend(100, lang).toString(),
					recommender2.recommend(100, lang).toString());
			
			t = System.currentTimeMillis();
			for (int i = 0; i < nIters; i++) {
				baseline.recommend(nElems, lang);
			}
			t = System.currentTimeMillis() - t;
			System.out.println("\tLa implementación de referencia tarda " + t + "ms");

			assertTimeoutPreemptively(Duration.ofMillis((long) (t * scales.get(lang))), () -> {
				t = System.currentTimeMillis();
				for (int i = 0; i < nIters; i++) {
					recommender2.recommend(nElems, lang);
				}
				t = System.currentTimeMillis() - t;
				System.out.println("\tLa implementación del alumno tarda " + t + "ms");
			});
		}
	}

	// Este es opcional, no hacemos pruebas
//	@Test
//	public void testEj4() throws FileNotFoundException {
//
//	}
	
	public static String checkDependencies() {
		try {
		} catch(Throwable t) {
			t.printStackTrace(System.out);
			return "Error al cargar las clases Movie, Comparator, MovieTester, DefaultSorter, DefaultRecommender, LanguageRecomender, LanguagePopularitySorter o algunos de sus métodos. Repasar identificadores y firmas de métodos";
		}
		return null;
	}
	
	public static void main(String args[]) {
	    //No dejamos que el alumno escriba en la salida 
	    PrintStream o = System.out;
	    PrintStream p;
	    try{
	        //Si estamos en Linux
	        p = new PrintStream(new FileOutputStream("/dev/null"));
	    }
	    catch(FileNotFoundException e){
	            //Si estamos en Windows
	            try {
					p = new PrintStream(new FileOutputStream("E:\\tmp\\kk.txt"));
				} catch (FileNotFoundException e1) {
					return;
				}
	    }
	    
	    System.setOut(p);
	    System.setErr(p);
	    //Pasamos las pruebas
	    Result result = JUnitCore.runClasses(Corrector.class);
	    String fails = "", cadena;
	
	    //Si han fallado todos los tests es que su constructor va mal
	    if(result.getFailureCount()==result.getRunCount() && result.getFailures().get(0).getMessage()==null){
	            fails = "<p>No se han podido realizar pruebas a su entrega: Compruebe que el constructor de su clase funciona de forma correcta. </p>";
	    }
	    //Recuperamos los mensajes de las pruebas que han fallado
	    else {
	    	  for (Failure failure : result.getFailures()) {
	              cadena = failure.getMessage();
	              //Si se produjo un timeout necesitamos saber en que metodo para cambiar el mensaje
	              if(cadena!=null && cadena.contains("timed out")){
	                      String metodo = failure.getTestHeader().split("_")[0];
	                      cadena = "<p>Error detectado al probar el metodo "+metodo+": Ha excedido el tiempo de prueba. Compruebe que no tiene bucles infinitos en su codigo.</p> ";
	              }
	              fails += cadena;
	    	  }
		}
	
		System.setOut(o);
		//Para depurar en Eclipse
		System.out.println(result.getRunCount());
		System.out.println(result.getFailureCount());
		System.out.println(fails);
		
		System.exit(-1);
	}
	
	private class LangPopComparator implements Comparator<Movie> {
		public int compare(Movie m1, Movie m2) {
			int c1 = m1.getOriginalLanguage().compareTo(m2.getOriginalLanguage());
			if(c1 != 0 ) {
				return c1;
			}
			return Float.valueOf(m1.getPopularity()).compareTo(Float.valueOf(m2.getPopularity()));
		}
	}
	


	// Comparador base para el Ej2.
	class BaselineComparator implements Comparator<Movie>{

		@Override
		public int compare(Movie o1, Movie o2) {
			return Float.compare(o2.getPopularity(), o1.getPopularity());
		}
	};

	// Comparador base para el Ej3.
	class ScoreComparator implements Comparator<Movie>{
		String lang;
		
		public ScoreComparator(String lang) {
			this.lang = lang;
		}
		
		private float score(Movie movie) {
			if(this.lang == null || movie.getOriginalLanguage().equals(this.lang)) {
				return movie.getPopularity();
			} else {
				return movie.getPopularity() / 2;
			}
		}

		@Override
		public int compare(Movie o1, Movie o2) {
			return Float.compare(this.score(o2), this.score(o1));
		}
	};

	// Recomendador de referencia para el Ej3.
	class BaselineLanguageRecommender implements Recommender {
		List<Movie> peliculas;
		public BaselineLanguageRecommender(List<Movie> pelis) {
			this.peliculas = pelis;
		}

		@Override
		public List<Movie> recommend(int n) {
			return this.recommend(n, null);
		}
		@Override
		public List<Movie> recommend(int n, String lang) {
			return this.peliculas.stream().sorted(new ScoreComparator(lang)).limit(n).collect(Collectors.toList());

		}
	}

}
