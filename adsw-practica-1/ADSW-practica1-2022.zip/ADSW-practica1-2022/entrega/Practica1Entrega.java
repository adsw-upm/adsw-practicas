
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestIdentifier;
import org.junit.platform.launcher.core.LauncherFactory;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;
import org.junit.platform.launcher.listeners.TestExecutionSummary.Failure;
import es.upm.dit.moodle.evaluation.server.curl.JCurl;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleAssignment;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleCourse;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleRequest;
import es.upm.dit.moodle.evaluation.server.moodle.client.MoodleUser;
import es.upm.dit.tokenbuilder.TokenBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class Practica1Entrega {
	private static final String course="3301";
	private static final String assignment="Practica1Entrega";
	private static final String PROJECTNAME="ADSW-practica1-2022";
	private static final String ZIPFILENAME=PROJECTNAME + ".zip";
	private static final String srcPath=System.getProperty("user.dir")+File.separator+"src";
	// inv2122-38@gate.upm.es
	// invitA292)
	

	private static File zipFile=null;
	private static TestExecutionSummary result;
	
	public static boolean start=false;
	
	private static void buildZip(File zipFile, File dirObj, File base) throws Exception {
	    ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFile));
	    addDir(dirObj, out, base);
	    out.close();
	}

	private static void addDir(File dirObj, ZipOutputStream out, File base) throws IOException {
	    File[] files = dirObj.listFiles();
	    byte[] tmpBuf = new byte[1024];

	    for (int i = 0; i < files.length; i++) {
	      if (files[i].isDirectory()) {
	        addDir(files[i], out, base);
	        continue;
	      }
	      String relative = base.toURI().relativize(files[i].toURI()).getPath();
	      FileInputStream in = new FileInputStream(files[i].getAbsolutePath());
	      System.out.println(" Adding: " + files[i].getAbsolutePath());
	      out.putNextEntry(new ZipEntry(relative));
	      int len;
	      while ((len = in.read(tmpBuf)) > 0) {
	        out.write(tmpBuf, 0, len);
	      }
	      out.closeEntry();
	      in.close();
	    }
	}
	
	private static void fileUploadInMoodle(String fileName, String filePath, String token) {
		try {
			MoodleCourse mc=MoodleCourse.MoodleCourseBuilder.instance(token).build(course,token);
			if (mc == null) {
				System.out.println("Error en la localización del curso en moodle");
				System.exit(-1);
			}
			MoodleAssignment pp=mc.getAssignment(assignment);
			if (pp == null) {
				System.out.println("Error en la localización de la práctica ("+assignment+") en el curso en moodle");
				System.exit(-1);				
			}
			JSONArray res = pp.saveUserSubmission(token, fileName, filePath);
			if (!res.isEmpty()) {
				System.out.println("Error salvando en moodle el fichero zip "+filePath+" en la práctica "+assignment);
				System.exit(-1);				
			}
		} catch (Exception e) {
			System.out.println("Error en la interaccion con moodle.");
			e.printStackTrace();
			System.exit(-1);				
		} 
	}
	
	private static void checkServices() {
		try {
			HttpURLConnection connection;
	        connection = (HttpURLConnection) new URL("https://moodle.upm.es").openConnection();
	        connection.setConnectTimeout(5000);
	        connection.setReadTimeout(5000);
	        connection.setRequestMethod("HEAD");
	        int responseCode = connection.getResponseCode();
	        boolean reachable=(200 <= responseCode && responseCode <= 399);
	        if (!reachable) {
				System.out.println("El servidor de moodle.upm.es no está disponible");
				System.exit(-1);
	        }
		} catch (Throwable t) {
			System.out.println("Error intentando acceder al servidor de moodle. La práctica sólo se puede entregar con acceso a internet."+t.getMessage());
			System.exit(-1);
		}
		try {
			JCurl jcurl = JCurl.builder()
				    .method(JCurl.HttpMethod.GET)
				    .build();
			HttpURLConnection connection = jcurl.connect(MOODLEEVAL+"version");
			JCurl.Response response = jcurl.processResponse(connection);
			String result=response.getOutput();
			String v=new JSONObject(result).getString("Version");

		} catch (Throwable t) {
			System.out.println("Error intentando acceder al servidor de almacenamiento de notas. Puedes subir zip, pero no la nota. "+t.getMessage());
		}
	}
	
    private static void checkJUnit() {
       	String msg=null;
		try {
			msg=Corrector.checkDependencies();
			if (msg != null)
				throw new Exception(msg);
			Class<LauncherDiscoveryRequestBuilder> x = LauncherDiscoveryRequestBuilder.class;
			x.getMethods();
		} catch (Throwable t) {
			//t.printStackTrace(System.out);
			System.out.println("Error en el acceso a JUnit o en el acceso a las clases del alumno. La práctica no está correctamente importada, o tiene errores de compilación, o los identificadores no se ajustan al enunciado."+(msg != null ? msg : ""));
			System.exit(-1);
		}
    }
    
    private static void doBuildZip() {
		try {
			String user_dir=System.getProperty("user.dir");
			File src=new File(srcPath);
			if (!src.exists()) {
				System.out.println("No esta localizable la carpeta src: "+src.getAbsolutePath());
				System.exit(-1);				
			}
			zipFile=new File(user_dir+File.separator+ZIPFILENAME);
			if (zipFile.exists())
				if (!zipFile.delete()) {
					System.out.println("No se puede borrar la versión antigua de la entrega: "+zipFile.getAbsolutePath());
					System.exit(-1);
				}
			buildZip(zipFile,src,new File(user_dir+File.separator+".."));
		} catch (Throwable t) {
			System.out.println("Error al construir el zip de la entrega: "+t.getMessage());
			System.exit(-1);
		}
    }
    
    private static String runJUnit() {
	    String fails = "";
	    long testFoundCount = 0;
	    List<Failure> failures = null;
		try {
		    final LauncherDiscoveryRequest request = 
		            LauncherDiscoveryRequestBuilder.request()
		                                       .selectors(selectClass(Corrector.class))
		                                       .build();

		     final Launcher launcher = LauncherFactory.create();
		     final SummaryGeneratingListener listener = new SummaryGeneratingListener() {
		    	 @Override
		    	 public void executionStarted(TestIdentifier test) {
		    		 super.executionStarted(test);
		    		 System.out.print("*");
		    	 }
		     };

		     launcher.registerTestExecutionListeners(listener);
		     launcher.execute(request);

		      result = listener.getSummary();
		      testFoundCount = result.getTestsFoundCount();
		      failures = result.getFailures();
		      
		      System.out.println("Se ejecutan " + testFoundCount + " pruebas");
		} catch (Throwable t) {
			System.out.println("Error al cargar el evaluador. La evaluación no se puede hacer con errores de compilación, o si identificadores y signaturas de la práctcia no se ajustan al enunciado.");
			System.exit(-1);
		} 
	
	    //Si han fallado todos los tests es que su constructor va mal
	    if(result == null || testFoundCount == 0 && failures != null && failures.get(0).getException().getMessage() == null){
	        fails = "No se han podido realizar pruebas a su entrega: Compruebe su clase y el paquete tienen nombres correctos y que los constructores de su clase funcionan de forma correcta";
	    }
	    else {
	    	  for (Failure failure : result.getFailures()) {
	              String cadena = failure.getException().getMessage();
	              if(cadena!=null && cadena.contains("timed out")){
	                      cadena = "Error por exceso de tiempo de prueba. Compruebe que no tiene bucles infinitos en su codigo.";
	              }
	              fails += "\n"+cadena+".";
	    	  }
		}
	    return fails;
    }
    
    private static String getKey(String token) {
    	char[] ctoken=token.toCharArray();
    	for (int i=0; i < ctoken.length; i++)
    		if (ctoken[i] <= '9' && ctoken[i] >= '0')
    			ctoken[i]=(char) ('0'+(ctoken[i]-'0'+1)%10);
    	return new String(ctoken);
    }
    
    private static String computeGrade() {
    	return ""+10.0*result.getTestsSucceededCount()/result.getTestsFoundCount();
    }

	private static final String MOODLEEVAL="https://moodleserverevaluation.appspot.com/moodle/v1/moodleeval/";
	// private static final String MOODLEEVAL="http://127.0.0.1:8888/moodle/v1/moodleeval/";
	
    private static String recordGrade(String token, String login, String passwd, String grade) {
		String gradeResponse=null;
		try {
			if (token == null)
				token=MoodleUser.getToken(login, passwd, MoodleRequest.DOMAIN_DEFAULT);
			else
				login=MoodleUser.getUseremail(token);

			JCurl jcurl = JCurl.builder()
				    .method(JCurl.HttpMethod.POST)
				    .data("{\"key\":\""+getKey(token)+"\",\"course\":\""+course+"\",\"assignment\":\""+assignment+"\",\"user\":\""+login+"\",\"grade\":\""+grade+"\",\"doLock\":\"true\"}")
				    .build();

			HttpURLConnection connection;
			connection = jcurl.connect(MOODLEEVAL+"setAssignmentGrade");

			JCurl.Response response = jcurl.processResponse(connection);
			gradeResponse=response.getOutput();
			String rgrade=new JSONObject(gradeResponse).getString("Grade");
			return rgrade;
		} catch (Throwable e) {
			String error=null;
			try {
				if (gradeResponse != null)
					error=new JSONObject(gradeResponse).getString("Error");
			} catch(Throwable t) {}
			System.out.println("Error al registrar en moodle la evaluación. "+(error != null ? error : e.getMessage()));
			return null;
		}
    }
    
    private static String unlockAssignment(String token, String login, String passwd) {
		String unlockResponse=null;
		try {
			if (token == null)
				token=MoodleUser.getToken(login, passwd, MoodleRequest.DOMAIN_DEFAULT);
			else
				login=MoodleUser.getUseremail(token);

			JCurl jcurl = JCurl.builder()
				    .method(JCurl.HttpMethod.POST)
				    .data("{\"key\":\""+getKey(token)+"\",\"course\":\""+course+"\",\"assignment\":\""+assignment+"\",\"user\":\""+login+"\"}")
				    .build();

			HttpURLConnection connection;
			connection = jcurl.connect(MOODLEEVAL+"unlockAssignment");

			JCurl.Response response = jcurl.processResponse(connection);
			unlockResponse=response.getOutput();
			String result=new JSONObject(unlockResponse).getString("Unlock");
			return result;
		} catch (Throwable e) {
			String error=null;
			try {
				if (unlockResponse != null)
					error=new JSONObject(unlockResponse).getString("Error");
			} catch(Throwable t) {}
			System.out.println("Error al desbloquear entrega en moodle. "+(error != null ? error : e.getMessage()));
			return null;
		}
    }
	
    @FunctionalInterface
    public static interface LoginHandler {
    		public void loginDone(String login,String passwd, String course, String assignment);
    }
    
	private static TokenBuilder tb;
	
    public static final void main(String[] args) {
		if (java.lang.management.ManagementFactory.getRuntimeMXBean().
		         getInputArguments().toString().indexOf("-agentlib:jdwp") > 0) {
			System.out.println("La entrega de prácticas no se debe ejecutar en modo de depuración");
			System.exit(-1);
		}
		start=true;
    	System.out.println("Comprobando el codigo");
    	String failDependencies = Corrector.checkDependencies() ;
    	if (failDependencies != null) {
			System.out.println("Se han encontrado fallos en la ejecución.\nDebe ser usted mismo quien encuentre esos fallos depurando la práctica. Estas son simples indicaciones:");
			System.out.println(failDependencies);
		}
    	
    	checkJUnit();	
    	
    	System.out.println("Ejecutando las pruebas");
	    String fails=runJUnit();
	    if (fails.length() > 0) {
			System.out.println("Se han encontrado fallos en la ejecución.\nDebe ser usted mismo quien encuentre esos fallos depurando la práctica. Estas son simples indicaciones:");
			System.out.println(fails);
		}
	    String grade=computeGrade();
	    System.out.println();
		System.out.println("La nota calculada ha sido: "+grade);
		System.out.println("Esta calificación es simplemente una orientación.");
		System.out.println("La evaluación definitiva se realizará cuando acabe el plazo de entrega de esta práctica.");
		System.out.println("Esta herramienta de entrega de prácticas está en pruebas.");
 
		System.out.println("Si desea finalizar aqui sin entregar la práctica en moodle cerrar el browser de moodle");
	   	System.out.println("Si desea entregar esta práctica en moodle ahora, entrar en moodle");
	   	
		System.out.println("Probando Servicios");
    	checkServices();
		System.out.println("Construyendo el fichero zip");
    	doBuildZip();
    	
	   	System.out.println("Si desea entregar esta práctica en moodle debes logarte en moodle antes de 2 minutos. \nSi cierras el browser de moodle o si tardas mas de 2 minutos no se hace entrega.");
	    new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					Thread.sleep(180000);
				} catch (InterruptedException e) {
				}
				if (tb != null && tb.getMoodleToken() == null) {
					System.out.println("El logado de moodle no se ha podido completar, y no se ha podido subir el fichero zip");
		    		System.out.println("Si refrescas (boton derecho sobre el proyecto->Refresh) en eclipse el proyecto de esta entrega, verás el fichero "+ZIPFILENAME+" que puedes subir a moodle");
					System.exit(0);
				}
			}
	    	
	    }).start();
	    tb=new TokenBuilder();
	    tb.start();
	   	String token=tb.getMoodleToken();
	   	if (token == null) {
	   		System.out.println("El logado de moodle no se ha podido completar, y no se ha podido subir el fichero zip");
	   		System.exit(0);
	   	}

    	try {
    		String runlock=unlockAssignment(token,null,null);
    		if (runlock == null) {
        		System.out.println("Error desbloqueando la entrega en moodle. ");
    			System.exit(-1);
    		}
    	} catch(Throwable t) {
    		System.out.println("Error desbloqueando la entrega en moodle. "+t.getMessage());
			System.exit(-1);
    	}

    	System.out.println("Subiendo Zip a Moodle. Esto puede durar un par de minutos");
    	try {
    		fileUploadInMoodle(ZIPFILENAME,zipFile.getAbsolutePath(),token);
    		System.out.println("Si refrescas (boton derecho sobre el proyecto->Refresh) en eclipse el proyecto de esta entrega, verás el fichero "+ZIPFILENAME+" que has subido a moodle");
    	} catch(Throwable t) {
    		System.out.println("Error al actualizar la entrega en moodle. "+t.getMessage());
			System.exit(-1);
    	}
    	System.out.println("Vamos a actualizar la nota en Moodle (esto puede llevar un par de minutos)");
    	try {
    		String rgrade=recordGrade(token,null,null,grade);
    		if (rgrade == null) {
        		System.out.println("Error al actualizar la nota en moodle. ");
    			System.exit(-1);
    		}
    	} catch(Throwable t) {
    		System.out.println("Error al actualizar la nota en moodle. "+t.getMessage());
			System.exit(-1);
    	}
    	System.out.println("Entrega realizada con exito. Conviene comprobarlo en moodle.");
    	System.exit(0);

    }
}
