package es.upm.dit.adsw.p1.ej2;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import es.upm.dit.adsw.movies.Movie;
import es.upm.dit.adsw.movies.MovieSorter;
import es.upm.dit.adsw.movies.Recommender;
import es.upm.dit.adsw.p1.ej1.DefaultSorter;

/**
 * Implementación de referencia del recomendador de películas.
 * 
 * Los métodos de recomendación utilizan la popularidad como criterio, devolviendo las películas con
 * mayor popularidad primero.
 *
 */
public class DefaultRecommender implements Recommender{
	List<Movie> movies;
	
	/**
	 * Crea un nuevo recomendador a partir de un fichero con la información de las películas.
	 * 
	 * @param metadata Fichero TSV con la información de las películas.
	 * @throws FileNotFoundException
	 */
	public DefaultRecommender(String metadata) throws FileNotFoundException {
		this(Movie.allFromFile(metadata));
	}
	
	/**
	 * Crea un nuevo recomendador a partir de una lista de películas.
	 * 
	 * @param movies lista de películas que podrán recomendarse
	 * @throws FileNotFoundException
	 */

	public DefaultRecommender(List<Movie> movies) throws FileNotFoundException {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
	}
	
	/* Recomienda varias películas, en orden de popularidad. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n) {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		return new ArrayList<Movie>();
		//FIN DEL CÓDIGO
	}

	/* Recomienda varias películas que tengan como idioma original el indicado, en orden de popularidad. 
	 * 
	 * El tamaño de la lista puede ser menor que n, si no hay suficientes películas en ese idioma. 
	 * 
	 * @param n número máximo de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang
	 */
	@Override
	public List<Movie> recommend(int n, String lang) {
		List<Movie> output = new ArrayList<Movie>();
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
		return output;
	}

}
