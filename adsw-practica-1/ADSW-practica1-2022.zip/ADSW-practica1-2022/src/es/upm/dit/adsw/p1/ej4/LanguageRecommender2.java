package es.upm.dit.adsw.p1.ej4;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.tools.ant.types.resources.Sort;

import es.upm.dit.adsw.movies.Movie;
import es.upm.dit.adsw.movies.MovieSorter;
import es.upm.dit.adsw.movies.Recommender;
import es.upm.dit.adsw.p1.ej1.DefaultSorter;

/**
 * Recomendador de películas utilizando un comparador de películas personalizado (LanguagePopularitySorter).
 * 
 * Los métodos de recomendación utilizan la popularidad como criterio, devolviendo las películas con
 * mayor popularidad primero.
 *
 */
public class LanguageRecommender2 implements Recommender{
	/**
	 * Lista de películas que se pueden recomendar
	 */
	List<Movie> peliculas;

	/**
	 * Crea un recomendador de películas a partir de un fichero de películas
	 * 
	 * @param metadata ruta del fichero con la información de películas
	 * @throws FileNotFoundException si el fichero de información no existe
	 */
	public LanguageRecommender2(String metadata) throws FileNotFoundException {
		this.peliculas = Movie.allFromFile(metadata);
	}
	
	/**
	 * Crea un recomendador a partir de una lista de películas existente
	 * @param movies lista de películas
	 */
	public LanguageRecommender2(List<Movie> movies) {
		// Ordenamos la lista para poder recomendar rápidamente
		MovieSorter sorter = new DefaultSorter();
		Movie[] array = this.peliculas.toArray(Movie[]::new);
		sorter.sort(array);
		this.peliculas = Arrays.asList(array);
	}
	
	/* Recomienda varias películas, en orden de popularidad. 
	 * 	
	 * @param n número de películas a recomendar
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n) {
		return this.peliculas.subList(0, n);
	}

	/* Recomienda varias películas que tengan como idioma original el indicado, en orden de popularidad. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n, String lang) {
		// Hay que tener cuidado de no cambiar el orden de la lista de peliculas si queremos
		// que recommend(int n) siga funcionando bien. Si se crea un array nuevo a partir de la lista
		// la lista original no se modificará aunque se reordene el array.
		
		MovieSorter sorter = new CustomSorter(new LanguagePopularityComparator(lang));
		Movie[] array = this.peliculas.toArray(Movie[]::new);
		sorter.sort(array);
		return Arrays.asList(array).subList(0, n);
	}

}
