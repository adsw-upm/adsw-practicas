package es.upm.dit.adsw.p1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.util.List;

import org.junit.jupiter.api.Test;

import es.upm.dit.adsw.movies.Movie;
import es.upm.dit.adsw.movies.Recommender;
import es.upm.dit.adsw.p1.ej4.LanguageRecommender2;


/**
 * Conjunto de pruebas para las clases del paquete es.upm.dit.adsw.movies
 * 
 * Se pueden u
 *
 */
class P1Tester {

	@Test
	void testEj1() {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
	}
	
	@Test
	void testEj2() {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
	}
	
	@Test
	void testEj3() {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
	}



	/**
	 * Pruebas para ayudar en el desarrollo del Ejercicio 4.
	 * No son pruebas exhaustivas, sólo se comprueba el resultado para dos idiomas.
	 * @throws FileNotFoundException
	 */
	
	// Descomentar el código a continuación para probar el Ejercicio 4.
	/*
	@Test
	void testEj4() throws FileNotFoundException {	
		Recommender recommender = new LanguageRecommender2("data/metadata.tsv");
		List<Movie> recomendadas = recommender.recommend(1000, "de");
		// Sabemos que la recomendación 121 debe ser "Metropolis"
		assertEquals(recomendadas.get(121).getTitle(), "Metropolis");
		
		// Debería haber 1000 recomendaciones
		assertEquals(recomendadas.size(), 1000);
		
		// De las 1000 recomendaciones, 52 películas deberían ser en alemán
		// Este código utiliza Java streams para procesar la lista. Se podría conseguir un efecto similar
		// con un bucle, contando el número de películas que cumplen la condición.
		assertEquals(recomendadas.stream().filter(s -> s.getOriginalLanguage().equals("de")).count(), 52);
		
		// Probamos de nuevo para otro idioma (mandarín)
		recomendadas = recommender.recommend(1000, "zh");
		assertEquals(recomendadas.size(), 1000);
		// De las 1000 recomendaciones, 29 películas deberían ser en mandarín
		assertEquals(recomendadas.stream().filter(s -> s.getOriginalLanguage().equals("zh")).count(), 29);
	}
	*/
}
