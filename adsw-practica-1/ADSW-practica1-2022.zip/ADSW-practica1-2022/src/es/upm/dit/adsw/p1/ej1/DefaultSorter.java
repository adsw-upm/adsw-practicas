package es.upm.dit.adsw.p1.ej1;

import java.util.Arrays;
import java.util.Collections;

import es.upm.dit.adsw.movies.Movie;
import es.upm.dit.adsw.movies.MovieSorter;

/**
 * Clase que permite ordenar una lista de películas utilizando el método por defecto de comparación.
 * Es decir, utiliza el método {@link es.upm.dit.adsw.movies#compareTo}.
 *  
 */
public class DefaultSorter implements MovieSorter {

	/**
	 * Ordena el array de películas.
	 * 
	 * Se puede utilizar cualquiera de los algoritmos vistos en clase, o la biblioteca estándar de Java.
	 */
	public void sort(Movie[] movies) {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
	}
}
