package es.upm.dit.adsw.p1.ej3;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import es.upm.dit.adsw.movies.Movie;
import es.upm.dit.adsw.movies.MovieSorter;
import es.upm.dit.adsw.movies.Recommender;
import es.upm.dit.adsw.p1.ej1.DefaultSorter;

/**
 * Recomendador de películas optimizado para recomendación en idiomas.
 * 
 * Los métodos de recomendación utilizan la popularidad como criterio, devolviendo las películas con
 * mayor popularidad primero.
 *
 */
public class LanguageRecommender implements Recommender{
	/**
	 * Para cada idioma, tendremos un "cubo" o bucket con todas las películas en ese idioma.
	 */
	List<Movie[]> buckets;

	public LanguageRecommender(String metadata) throws FileNotFoundException {
		this((List<Movie>) Movie.allFromFile(metadata));
	}
	
	public LanguageRecommender(List<Movie> movies) {
		List<List<Movie>> buckets = new ArrayList<List<Movie>>();
		
		// Filtrar cada película por idioma
		for(Movie movie: movies) {
			boolean found = false;
			// Buscar a qué cubo pertenece esta película
			for(List<Movie> bucket: buckets) {
				if(bucket.isEmpty()) {
					continue;
				}
				if(bucket.get(0).getOriginalLanguage().equals(movie.getOriginalLanguage())) {
					bucket.add(movie);
					found = true;
					break;
				}
			}
			// Añadir un cubo nuevo si no se encuentra uno para ese idioma
			if(!found) {
				List<Movie> newLang = new ArrayList<Movie>();
				newLang.add(movie);
				buckets.add(newLang);
				
			}
		}
		
		MovieSorter sorter = new DefaultSorter();
		this.buckets = new ArrayList<Movie[]>();
		// Para cada idioma, convertir a array y ordenar
		for(List<Movie> bucket: buckets) {
			Movie[] array = bucket.toArray(Movie[]::new);
			sorter.sort(array);
			this.buckets.add(array);

		}
	}
	
	
	/* Recomienda varias películas, en orden de popularidad. 
	 * 	
	 * @param n número de películas a recomendar
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n) {
		List<Movie> result = new ArrayList<Movie>(n);
		// Elemento actual que estamos considerando en cada uno de los cubos
		int[] indices = new int[buckets.size()];
		// Añadimos elementos al resultado, uno a uno
		for(int i=0; i<n; i++) {
			// Índice del cubo con el elemento mayor
			int max_bucket = -1;
			Movie max_movie = null;
			for(int j=0; j< this.buckets.size(); j++) {
				if(indices[j] >= this.buckets.get(j).length) {
					continue;
				}
				Movie candidate = this.buckets.get(j)[indices[j]];
				if(max_bucket < 0 || max_movie.getPopularity() < candidate.getPopularity()) {
					max_bucket = j;
					max_movie = candidate;
				}
			}
			// Si ya no hay cubos de los que extraer películas, devolver los resultados que tengamos
			if(max_bucket < 0) {
				return result;
			}
			result.add(max_movie);
			indices[max_bucket] += 1;
		}
		return result;
	}

	/* Recomienda varias películas que tengan como idioma original el indicado, en orden de popularidad. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n, String lang) {
		List<Movie> result = new ArrayList<Movie>(n);
		int[] indices = new int[buckets.size()];
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
		return result;
	}

}
