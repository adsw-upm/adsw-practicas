package es.upm.dit.adsw.p1.ej4;

import java.util.Arrays;
import java.util.Comparator;

import es.upm.dit.adsw.movies.Movie;
import es.upm.dit.adsw.movies.MovieSorter;


/**
 * Comparador de películas que ordena utilizando el comparador que se especifique al construirlo.
 *
 */
public class CustomSorter implements MovieSorter {

	private Comparator<Movie> comparator;
	
	/**
	 * Crea un comparador que 
	 * 
	 * @param comparator
	 */
	public CustomSorter(Comparator comparator) {
		this.comparator = comparator;
	}
	
	/**
	 * Implementa la ordenación de películas utilizando this.comparator para comparar cada par de películas
	 */
	@Override
	public void sort(Movie[] movies) {
		// Implementar utilizando this.comparator
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO
	}

}
