package es.upm.dit.adsw.p1.ej4;

import java.util.Comparator;

import es.upm.dit.adsw.movies.Movie;

class LanguagePopularityComparator implements Comparator<Movie> {
	String lang;
	
	/**
	 * Construye un comparador que da una puntuación mayor a las películas que tienen lang (p.e., "es" o "en")
	 * como idioma original
	 * @param lang
	 */
	public LanguagePopularityComparator(String lang) {
		this.lang = lang;
	}
	
	@Override
	public int compare(Movie m1, Movie m2) {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		return 0
		//FIN DEL CÓDIGO
	}
}
