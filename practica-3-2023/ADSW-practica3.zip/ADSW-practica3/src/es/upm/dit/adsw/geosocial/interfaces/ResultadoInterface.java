package es.upm.dit.adsw.geosocial.interfaces;

import java.util.List;
import java.util.Map;

import es.upm.dit.adsw.geosocial.Localizacion;

/**
 * @author aalonso
 * Este interface representa el resultado generado una hebra al procesar un 
 * segmento. El resultado está representante en un 
 * diccionarion, en el que la clave
 * es una localización y el valor es una lista de los usuarios que han estado
 * en ella.
s */

public interface ResultadoInterface {

	/**
	 * @author aalonso
	 * El resultado al procesar un segmento
	 * @return: El diccionario del resultado
	 */

	Map<Localizacion, List<Integer>> getResultado();
		
}

