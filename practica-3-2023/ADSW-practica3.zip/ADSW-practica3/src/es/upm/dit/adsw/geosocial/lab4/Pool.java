package es.upm.dit.adsw.geosocial.lab4;

import es.upm.dit.adsw.geosocial.interfaces.MonitorSegmentosInterface;

/**
 * @author aalonso
 * Esta clase permite arrancar un conjunto de hebras. 
 */
public class Pool {

	private Hebra[] hebras; 
	private int nHebras;
	private MonitorSegmentosInterface monitor;
	
	/**
	 * Constructor de la clase pool
	 * @param nHebras Número de hebras que hay que crear
	 * @param monitor Monitor que se requiere para comunicar adecuadamente
	 *                las hebras con el gestor.
	 */
	public Pool (int nHebras, MonitorSegmentosInterface monitor) {
		this.nHebras = nHebras;
		this.hebras  = new Hebra[nHebras];
		this.monitor = monitor;
	}
	
	/**
	 * Crear las hebras, de acuerdo con el constructor.
	 */
	public void activate() {
		for (int i = 0; i < nHebras; i++) {
			hebras[i] = new Hebra(monitor, i);
			hebras[i].start();
		}

	}
	
}
