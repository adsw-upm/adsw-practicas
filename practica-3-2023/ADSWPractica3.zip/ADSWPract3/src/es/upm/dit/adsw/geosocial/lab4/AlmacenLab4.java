package es.upm.dit.adsw.geosocial.lab4;


import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.ConsoleHandler;
import java.util.logging.Logger;
import java.util.logging.Level;

import es.upm.dit.adsw.geosocial.GeoAlmacen;
import es.upm.dit.adsw.geosocial.Localizacion;
import es.upm.dit.adsw.geosocial.interfaces.MonitorSegmentosInterface;
import es.upm.dit.adsw.geosocial.interfaces.ResultadoInterface;
import es.upm.dit.adsw.geosocial.interfaces.SegmentoInterface;
import es.upm.dit.adsw.geosocial.monitor.MonitorSegmentos;


public class AlmacenLab4 extends GeoAlmacen{

	private int id = -1;


	// Lista de segmentos que hay que procesar
	protected List<SegmentoInterface> segmentos = new ArrayList<SegmentoInterface>();

	// Lista para almacenar los resultados
	protected List<ResultadoInterface> resultados 
	= new  ArrayList<ResultadoInterface>();

	// Lista con la inversión de las localizaciones
	protected Map<Localizacion, List<Integer>> inversionLocalizaciones = new HashMap<Localizacion, List<Integer>>();

	protected  MonitorSegmentosInterface monitor;

	protected int nSegmentos;

	static {
		System.setProperty("java.util.logging.SimpleFormatter.format",
				"[%1$tF %1$tT][%4$-7s] [%5$s] [%2$-7s] %n");
	}

	//static Logger LOGGER; 
	static final Logger LOGGER = Logger.getLogger(AlmacenLab4.class.getName());

	/**
	 * Se recibe un objeto de la clas4 GeoAlmacen. Los datos de la red están representados en 
	 * el objeto. Además, se determina el número de segmentos. 
	 * @param almacen Objeto que representa la red scocial
	 * @param nSegmentos Número de segmentos
	 * @param monitor     para la comunicación con hebras
	 */
	public AlmacenLab4(GeoAlmacen almacen, int nSegmentos, MonitorSegmentosInterface monitor) {
		configurarLogger();
		// En el constructor se leen de los datos y generan los segmentos
		
		this.nSegmentos = nSegmentos;
		this.registros  = almacen.getRegistros();
		this.monitor    = monitor;
	}

	/**
	 * Se recibe un segmento que representa los registros del sistema. Igualmente, se indica
	 * el número de segmentos, por si se quiere para particionarlo. 
	 * @param segmento Segmento con los registros de la red
	 * @param nSegmentos Número de segmentos
	 * @param monitor     para la comunicación con hebras
	 */
	public AlmacenLab4(SegmentoInterface segmento, int nSegmentos, MonitorSegmentosInterface monitor) {
		configurarLogger();
		this.registros  = segmento.getRegistros();
		this.nSegmentos = nSegmentos;
		this.monitor    = monitor;
	}

	/**
	 * Recibe el nombre del fichero de la red social y número de segmentos. Accede
	 * a los ficheros y los guarda en estructuras de datos. 
	 * @param fichero Camino de la red social
	 * @param nSegmentos Número de segmentos
	 * @param monitor     para la comunicación con hebras
	 */
	public AlmacenLab4(String fichero, int nSegmentos, MonitorSegmentosInterface monitor) 
			throws FileNotFoundException, ParseException{
		super(fichero);
		configurarLogger();
		// En el constructor se leen de los datos y generan los segmentos
		this.nSegmentos = nSegmentos;
		//this.registros  = almacen.getRegistros();
		this.monitor    = monitor;
	}
 
	/**
	 * Configuracion de un logger
	 */
	private void configurarLogger() {
		//Configurar un handler
		ConsoleHandler handler;
		LOGGER.setUseParentHandlers(false);
		handler = new ConsoleHandler();		
		handler.setLevel(Level.WARNING);
		LOGGER.addHandler(handler);
		LOGGER.setLevel(Level.WARNING);

	}

	/**
	 * Integrar los resultados obtenidos de los fragmentos generados
	 */
	private void integrarResultados() {
		Map<Localizacion, List<Integer>> resultadoMap = null;
		for (ResultadoInterface resultado : resultados) {
			//System.out.println(resultado.toString());
			resultadoMap = resultado.getResultado();
			try {
				for (Localizacion localizacion : resultadoMap.keySet()) {
					if (inversionLocalizaciones.containsKey(localizacion)) {
						List<Integer> lista = resultadoMap.get(localizacion);
						for (Integer usuario : lista) {
							if (!inversionLocalizaciones.get(localizacion).contains(usuario)) {
								inversionLocalizaciones.get(localizacion).add(usuario);
							}							inversionLocalizaciones.get(localizacion).add(usuario);
						}
					} else {
						inversionLocalizaciones.put(localizacion, resultadoMap.get(localizacion));
					}
				} 
			} catch (Exception E) {
				AlmacenLab4.LOGGER.severe("Unexpected exception");				
			}
		}
		AlmacenLab4.LOGGER.info("Se han integrado " + inversionLocalizaciones.size() +  " resultados");
	}

	/**
	 * Los segmentos generados se envían al monitor, para enviarlos a las hebras. A continuación,
	 * hay que recibr los segmentos que han procesado
	 * @return Retorna la lista de los resultados recibidos
	 */
	public List<ResultadoInterface> procesarSegmentos() {
		int nResultados = 0;
		// TODO alumnos
		// Para segmento, enviarlo al monitor
		// Entrar en un bucle recibiendo resultados. 
		// Deben obtener tantos resultados como el número de segmentos
		// Finalizar el monitor cuando se han recibido todos. 
		
		AlmacenLab4.LOGGER.info("Se han recibido " + nResultados +  " resultados");
		integrarResultados();
		
		return resultados;
	}

	/**
	 * Retorna una lista de los usuarios que han accedido a una localización
	 * @param localizacion La localización accedida
	 * @return La lista de usuarios accedidos
	 */
	public List<Integer> getInversion(Localizacion localizacion) {
		return inversionLocalizaciones.get(localizacion);
	}


	/**
	 * Retorna el resultado de la inversión de la red. 
	 * @return El resultado
	 */
	public ResultadoInterface getInversiones() {
		return new Resultado(inversionLocalizaciones);
	}
	
	/**
	 * Mostrar los usuarios que han accedido a una localización
	 * @param localizacion La localización accedida
	 */
	public void printInversion(Localizacion localizacion) {
		List<Integer> usuarios = inversionLocalizaciones.get(localizacion);

		if (usuarios != null) {
			if (usuarios.size() > 0) {
				System.out.println(localizacion + " " + usuarios.size() + " usuarios");
				for (Integer usuario: usuarios) {
					System.out.println(usuario);					
				}
				return;
			}
		}
		System.out.println(localizacion + ": No han ido usuarios a la localización");
		return;
	}

	/**
	 * Generar los segmentos usando la clase Segmento
	 */
	public void generarSegmentos() {
		if (this.nSegmentos > registros.size()) this.nSegmentos = registros.size();
		segmentos = Segmento.generarSegmentos(nSegmentos, registros);
	}

	public static void main(String[] args) {

		MonitorSegmentosInterface monitor = new MonitorSegmentos();

		int nSegmentos = 4;
		int nHebras    = 3;

		try {
			String fichero  = "Locations0pr.tsv";
			String fichero1 = "Locations1pr.tsv";
	
			AlmacenLab4 inv = new AlmacenLab4(fichero, nSegmentos, monitor);

			Pool pool = new Pool(nHebras, monitor);
			pool.activate();

			inv.generarSegmentos();

			inv.procesarSegmentos();

			
			Localizacion loc = new Localizacion((float)40.7425115937, (float) -74.0060305595);
			Localizacion loc1= new Localizacion((float)30.2359091167, (float) -97.7951395833);

			inv.printInversion(loc);
			inv.printInversion(loc1);

			
		} catch (Exception E) {
			AlmacenLab4.LOGGER.severe("Unexpected interrupted exception");
		}

	}
}

