package es.upm.dit.adsw.geosocial.lab4;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import es.upm.dit.adsw.geosocial.Localizacion;
import es.upm.dit.adsw.geosocial.interfaces.MonitorSegmentosInterface;
import es.upm.dit.adsw.geosocial.monitor.MonitorSegmentos;

class Almacen4Lab_Test {

	private static AlmacenLab4 grafo1;
	private static AlmacenLab4 grafo2;
	private static int nSegmentos = 4;
	private static String fichero1 = "Locations0pr.tsv";
	private static String fichero2 = "Locations1pr.tsv";
	private static int nHebras = 3;
	private static Pool pool;
	
	@Test
	void test2() {
		// para el fichero Locations0pr.tsv

		MonitorSegmentosInterface monitor = new MonitorSegmentos();
		nSegmentos = 4;
		nHebras  = 3;
		
		try {
			grafo2 = new AlmacenLab4(fichero2, nSegmentos, monitor);
		} catch (Exception e) {
			e.printStackTrace();
		}

		pool = new Pool(nHebras, monitor);
		pool.activate();
		grafo2.generarSegmentos();
		grafo2.procesarSegmentos();
		
		// Para Locations0pr.tsv
		Localizacion loc1= new Localizacion((float)30.2359091167, (float) -97.7951395833);
		Localizacion loc2 = new Localizacion((float)40.7425115937, (float) -74.0060305595);
		Localizacion loc3= new Localizacion((float)10.2359091167, (float) -97.7951395833);

		List<Integer> list = grafo2.getInversion(loc1);
		assertEquals(list.size(), 7);
		list = grafo2.getInversion(loc2);
		assertEquals(list.size(), 1);
		list = grafo2.getInversion(loc3);
		assertEquals(list, null);
		
	}
	
	@Test
	void test1() {
		// para el fichero Locations0pr.tsv
		MonitorSegmentosInterface monitor = new MonitorSegmentos();
		nSegmentos = 4;
		nHebras  = 3;

		try {
			grafo1 = new AlmacenLab4(fichero1, nSegmentos, monitor);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			monitor.estaFinalizado();
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		pool = new Pool(nHebras, monitor);
		pool.activate();
		grafo1.generarSegmentos();
		grafo1.procesarSegmentos();
		
		// Para Locations0pr.tsv
		Localizacion loc1= new Localizacion((float)30.2359091167, (float) -97.7951395833);
		Localizacion loc2 = new Localizacion((float)40.7425115937, (float) -74.0060305595);
		Localizacion loc3= new Localizacion((float)10.2359091167, (float) -97.7951395833);

		List<Integer> list = grafo1.getInversion(loc1);
		assertEquals(list.size(), 2);
		list = grafo1.getInversion(loc2);
		assertEquals(list.size(), 1);
		list = grafo1.getInversion(loc3);
		assertEquals(list, null);
		
	}



	
}
